<section
    class="elementor-section elementor-top-section elementor-element elementor-element-46bf0a7e elementor-hidden-desktop elementor-hidden-tablet elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="46bf0a7e" data-element_type="section"
    data-settings='{"jet_parallax_layout_list":[{"_id":"7972e9e","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6e003693"
            data-id="6e003693" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-4a27c605 elementor-widget elementor-widget-heading"
                    data-id="4a27c605" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <h2 class="elementor-heading-title elementor-size-default">
                            Download App Sekolah
                        </h2>
                    </div>
                </div>
                <div class="elementor-element elementor-element-616cc955 elementor-widget elementor-widget-text-editor"
                    data-id="616cc955" data-element_type="widget" data-widget_type="text-editor.default">
                    <div class="elementor-widget-container">
                        Nikmati Cara Mudah dan Menyenangkan Ketika Membaca Buku,
                        Update Informasi Sekolah Hanya Dalam Genggaman
                    </div>
                </div>
                <div class="elementor-element elementor-element-58a41e86 elementor-widget elementor-widget-image"
                    data-id="58a41e86" data-element_type="widget" data-widget_type="image.default">
                    <div class="elementor-widget-container">
                        <a href="#">
                            <img width="320" height="95" src="wp-content/uploads/2022/03/play-store.png"
                                class="attachment-full size-full wp-image-118" alt=""
                                srcset="
                          https://sekolah.flymotion.my.id/wp-content/uploads/2022/03/play-store.png        320w,
                          https://sekolah.flymotion.my.id/wp-content/uploads/2022/03/play-store-300x89.png 300w
                        "
                                sizes="(max-width: 320px) 100vw, 320px" />
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section
    class="elementor-section elementor-top-section elementor-element elementor-element-521c60eb elementor-hidden-desktop elementor-hidden-tablet elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="521c60eb" data-element_type="section"
    data-settings='{"jet_parallax_layout_list":[{"_id":"0e9c51d","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-23fd8c38"
            data-id="23fd8c38" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-704fc402 elementor-widget elementor-widget-text-editor"
                    data-id="704fc402" data-element_type="widget" data-widget_type="text-editor.default">
                    <div class="elementor-widget-container">
                        <p>
                            Copyright © 2022 – Sekolah Template.<br />
                            All Rights Reserved. Made with ❤ by <a href="https://t.me/amaryourbae">flymotion.id</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
