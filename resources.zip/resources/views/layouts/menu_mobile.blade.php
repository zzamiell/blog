<section
    class="elementor-section elementor-top-section elementor-element elementor-element-139cd5f6 elementor-hidden-desktop elementor-hidden-tablet elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="139cd5f6" data-element_type="section"
    data-settings='{"jet_parallax_layout_list":[],"background_background":"classic","sticky":"bottom","sticky_on":["mobile"],"sticky_offset":0,"sticky_effects_offset":0}'>
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-346e99e5"
            data-id="346e99e5" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-5890c053 elementor-view-default elementor-widget elementor-widget-icon"
                    data-id="5890c053" data-element_type="widget" data-widget_type="icon.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-icon-wrapper">
                            <a class="elementor-icon" href="{{ route('index') }}">
                                <svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1"
                                    viewBox="0 0 24 24" width="512" height="512">
                                    <path
                                        d="M21.8,5.579,14.8.855A4.979,4.979,0,0,0,9.2.855l-7,4.724A5,5,0,0,0,0,9.724V19a5.006,5.006,0,0,0,5,5H19a5.006,5.006,0,0,0,5-5V9.724A5,5,0,0,0,21.8,5.579ZM22,19a3,3,0,0,1-3,3H5a3,3,0,0,1-3-3V9.724A3,3,0,0,1,3.322,7.237l7-4.724a2.986,2.986,0,0,1,3.356,0l7,4.724A3,3,0,0,1,22,9.724ZM12,7.006A6,6,0,0,0,7.765,17.257l1.824,1.784a3.465,3.465,0,0,0,4.821,0l1.833-1.792A6,6,0,0,0,12,7.006Zm2.836,8.821-1.825,1.785a1.454,1.454,0,0,1-2.023,0L9.171,15.835a4,4,0,1,1,5.665-.008ZM13,13a1,1,0,1,1-1-1A1,1,0,0,1,13,13Z">
                                    </path>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="elementor-element elementor-element-3813154a elementor-widget elementor-widget-heading"
                    data-id="3813154a" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <h2 class="elementor-heading-title elementor-size-default">
                            <a href="{{ route('index') }}">Home</a>
                        </h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-db5b0d"
            data-id="db5b0d" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-61b20440 elementor-view-default elementor-widget elementor-widget-icon"
                    data-id="61b20440" data-element_type="widget" data-widget_type="icon.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-icon-wrapper">
                            <a class="elementor-icon" href="{{ route('beritaComponent') }}">
                                <svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" height="512"
                                    viewBox="0 0 24 24" width="512" data-name="Layer 1">
                                    <path
                                        d="m17 14a1 1 0 0 1 -1 1h-8a1 1 0 0 1 0-2h8a1 1 0 0 1 1 1zm-4 3h-5a1 1 0 0 0 0 2h5a1 1 0 0 0 0-2zm9-6.515v8.515a5.006 5.006 0 0 1 -5 5h-10a5.006 5.006 0 0 1 -5-5v-14a5.006 5.006 0 0 1 5-5h4.515a6.958 6.958 0 0 1 4.95 2.05l3.484 3.486a6.951 6.951 0 0 1 2.051 4.949zm-6.949-7.021a5.01 5.01 0 0 0 -1.051-.78v4.316a1 1 0 0 0 1 1h4.316a4.983 4.983 0 0 0 -.781-1.05zm4.949 7.021c0-.165-.032-.323-.047-.485h-4.953a3 3 0 0 1 -3-3v-4.953c-.162-.015-.321-.047-.485-.047h-4.515a3 3 0 0 0 -3 3v14a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3z">
                                    </path>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="elementor-element elementor-element-5c724060 elementor-widget elementor-widget-heading"
                    data-id="5c724060" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <h2 class="elementor-heading-title elementor-size-default">
                            <a href="{{ route('beritaComponent') }}">Artikel</a>
                        </h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-18b8bf26"
            data-id="18b8bf26" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-3868172c elementor-view-default elementor-widget elementor-widget-icon"
                    data-id="3868172c" data-element_type="widget" data-widget_type="icon.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-icon-wrapper">
                            <a class="elementor-icon"
                                href="#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjU5NiIsInRvZ2dsZSI6ZmFsc2V9">
                                <svg xmlns="http://www.w3.org/2000/svg" id="Outline" viewBox="0 0 24 24"
                                    width="512" height="512">
                                    <path
                                        d="M7,0H4A4,4,0,0,0,0,4V7a4,4,0,0,0,4,4H7a4,4,0,0,0,4-4V4A4,4,0,0,0,7,0ZM9,7A2,2,0,0,1,7,9H4A2,2,0,0,1,2,7V4A2,2,0,0,1,4,2H7A2,2,0,0,1,9,4Z">
                                    </path>
                                    <path
                                        d="M7,13H4a4,4,0,0,0-4,4v3a4,4,0,0,0,4,4H7a4,4,0,0,0,4-4V17A4,4,0,0,0,7,13Zm2,7a2,2,0,0,1-2,2H4a2,2,0,0,1-2-2V17a2,2,0,0,1,2-2H7a2,2,0,0,1,2,2Z">
                                    </path>
                                    <path
                                        d="M20,13H17a4,4,0,0,0-4,4v3a4,4,0,0,0,4,4h3a4,4,0,0,0,4-4V17A4,4,0,0,0,20,13Zm2,7a2,2,0,0,1-2,2H17a2,2,0,0,1-2-2V17a2,2,0,0,1,2-2h3a2,2,0,0,1,2,2Z">
                                    </path>
                                    <path
                                        d="M14,7h3v3a1,1,0,0,0,2,0V7h3a1,1,0,0,0,0-2H19V2a1,1,0,0,0-2,0V5H14a1,1,0,0,0,0,2Z">
                                    </path>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="elementor-element elementor-element-32aee980 elementor-widget elementor-widget-heading"
                    data-id="32aee980" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <h2 class="elementor-heading-title elementor-size-default">
                            Menu
                        </h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-6f9b8fed"
            data-id="6f9b8fed" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-46944bf8 elementor-view-default elementor-widget elementor-widget-icon"
                    data-id="46944bf8" data-element_type="widget" data-widget_type="icon.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-icon-wrapper">
                            <a class="elementor-icon"
                                href="#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjYwNSIsInRvZ2dsZSI6ZmFsc2V9">
                                <svg xmlns="http://www.w3.org/2000/svg" id="Outline" viewBox="0 0 24 24"
                                    width="512" height="512">
                                    <path
                                        d="M24,11.247A12.012,12.012,0,1,0,12.017,24H19a5.005,5.005,0,0,0,5-5V11.247ZM22,19a3,3,0,0,1-3,3H12.017a10.041,10.041,0,0,1-7.476-3.343,9.917,9.917,0,0,1-2.476-7.814,10.043,10.043,0,0,1,8.656-8.761A10.564,10.564,0,0,1,12.021,2,9.921,9.921,0,0,1,18.4,4.3,10.041,10.041,0,0,1,22,11.342Z">
                                    </path>
                                    <path d="M8,9h4a1,1,0,0,0,0-2H8A1,1,0,0,0,8,9Z"></path>
                                    <path d="M16,11H8a1,1,0,0,0,0,2h8a1,1,0,0,0,0-2Z"></path>
                                    <path d="M16,15H8a1,1,0,0,0,0,2h8a1,1,0,0,0,0-2Z"></path>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="elementor-element elementor-element-14ce4001 elementor-widget elementor-widget-heading"
                    data-id="14ce4001" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <h2 class="elementor-heading-title elementor-size-default">
                            Kontak
                        </h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="elementor-column elementor-col-20 elementor-top-column elementor-element elementor-element-d034bd4"
            data-id="d034bd4" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-269d5771 elementor-view-default elementor-widget elementor-widget-icon"
                    data-id="269d5771" data-element_type="widget" data-widget_type="icon.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-icon-wrapper">
                            <a class="elementor-icon"
                                href="#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjU2NSIsInRvZ2dsZSI6ZmFsc2V9">
                                <svg xmlns="http://www.w3.org/2000/svg" id="Outline" viewBox="0 0 24 24"
                                    width="512" height="512">
                                    <path
                                        d="M23,16a1,1,0,0,0-1,1v2a3,3,0,0,1-3,3H17a1,1,0,0,0,0,2h2a5.006,5.006,0,0,0,5-5V17A1,1,0,0,0,23,16Z">
                                    </path>
                                    <path
                                        d="M1,8A1,1,0,0,0,2,7V5A3,3,0,0,1,5,2H7A1,1,0,0,0,7,0H5A5.006,5.006,0,0,0,0,5V7A1,1,0,0,0,1,8Z">
                                    </path>
                                    <path
                                        d="M7,22H5a3,3,0,0,1-3-3V17a1,1,0,0,0-2,0v2a5.006,5.006,0,0,0,5,5H7a1,1,0,0,0,0-2Z">
                                    </path>
                                    <path
                                        d="M19,0H17a1,1,0,0,0,0,2h2a3,3,0,0,1,3,3V7a1,1,0,0,0,2,0V5A5.006,5.006,0,0,0,19,0Z">
                                    </path>
                                    <path d="M12,11A4,4,0,1,0,8,7,4,4,0,0,0,12,11Zm0-6a2,2,0,1,1-2,2A2,2,0,0,1,12,5Z">
                                    </path>
                                    <path
                                        d="M18,20a1,1,0,0,0,1-1,6.006,6.006,0,0,0-6-6H11a6.006,6.006,0,0,0-6,6,1,1,0,0,0,2,0,4,4,0,0,1,4-4h2a4,4,0,0,1,4,4A1,1,0,0,0,18,20Z">
                                    </path>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="elementor-element elementor-element-6a6d3b48 elementor-widget elementor-widget-heading"
                    data-id="6a6d3b48" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <h2 class="elementor-heading-title elementor-size-default">
                            Login
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
