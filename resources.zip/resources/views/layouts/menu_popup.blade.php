<style id="elementor-post-dynamic-596">
    .elementor-596 .elementor-element.elementor-element-474d80f0.elementor-view-stacked .elementor-icon {
        background-color: #03626f;
    }

    .elementor-596 .elementor-element.elementor-element-474d80f0.elementor-view-framed .elementor-icon,
    .elementor-596 .elementor-element.elementor-element-474d80f0.elementor-view-default .elementor-icon {
        color: #03626f;
        border-color: #03626f;
    }

    .elementor-596 .elementor-element.elementor-element-474d80f0.elementor-view-framed .elementor-icon,
    .elementor-596 .elementor-element.elementor-element-474d80f0.elementor-view-default .elementor-icon svg {
        fill: #03626f;
    }

    .elementor-596 .elementor-element.elementor-element-6bed439a .elementor-nav-menu--dropdown a:hover,
    .elementor-596 .elementor-element.elementor-element-6bed439a .elementor-nav-menu--dropdown a.elementor-item-active,
    .elementor-596 .elementor-element.elementor-element-6bed439a .elementor-nav-menu--dropdown a.highlighted,
    .elementor-596 .elementor-element.elementor-element-6bed439a .elementor-menu-toggle:hover {
        color: #3f95a1;
    }

    .elementor-596 .elementor-element.elementor-element-6bed439a .elementor-nav-menu--dropdown a.elementor-item-active {
        color: #ffa800;
    }
</style>
<div data-elementor-type="popup" data-elementor-id="596" class="elementor elementor-596 elementor-location-popup"
    data-elementor-settings='{"entrance_animation":"fadeInDown","entrance_animation_mobile":"slideInUp","exit_animation":"fadeInDown","exit_animation_mobile":"slideInUp","entrance_animation_duration":{"unit":"px","size":0.5,"sizes":[]},"timing":[]}'>
    <div class="elementor-section-wrap">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-12b78554 elementor-hidden-desktop elementor-hidden-tablet elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="12b78554" data-element_type="section"
            data-settings='{"background_background":"classic","stretch_section":"section-stretched","jet_parallax_layout_list":[{"_id":"57bdfd9","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-3036aaa1"
                    data-id="3036aaa1" data-element_type="column" data-settings='{"background_background":"classic"}'>
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-474d80f0 elementor-view-default elementor-widget elementor-widget-icon"
                            data-id="474d80f0" data-element_type="widget" data-widget_type="icon.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-icon-wrapper">
                                    <a class="elementor-icon"
                                        href="#elementor-action%3Aaction%3Dpopup%3Aclose%26settings%3DeyJkb19ub3Rfc2hvd19hZ2FpbiI6IiJ9">
                                        <i aria-hidden="true" class="fas fa-chevron-down"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-2a2b8ce2 elementor-widget elementor-widget-image"
                            data-id="2a2b8ce2" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <a href="index.html">
                                    <img width="333" height="87" src="{{ asset($sekolah->logo) }}"
                                        class="attachment-full size-full wp-image-1215" alt=""
                                        sizes="(max-width: 333px) 100vw, 333px" />
                                </a>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-4ff78949 elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                            data-id="4ff78949" data-element_type="widget" data-widget_type="divider.default">
                            <div class="elementor-widget-container">
                                <style>
                                    /*! elementor - v3.21.0 - 26-05-2024 */
                                    .elementor-widget-divider {
                                        --divider-border-style: none;
                                        --divider-border-width: 1px;
                                        --divider-color: #0c0d0e;
                                        --divider-icon-size: 20px;
                                        --divider-element-spacing: 10px;
                                        --divider-pattern-height: 24px;
                                        --divider-pattern-size: 20px;
                                        --divider-pattern-url: none;
                                        --divider-pattern-repeat: repeat-x;
                                    }

                                    .elementor-widget-divider .elementor-divider {
                                        display: flex;
                                    }

                                    .elementor-widget-divider .elementor-divider__text {
                                        font-size: 15px;
                                        line-height: 1;
                                        max-width: 95%;
                                    }

                                    .elementor-widget-divider .elementor-divider__element {
                                        margin: 0 var(--divider-element-spacing);
                                        flex-shrink: 0;
                                    }

                                    .elementor-widget-divider .elementor-icon {
                                        font-size: var(--divider-icon-size);
                                    }

                                    .elementor-widget-divider .elementor-divider-separator {
                                        display: flex;
                                        margin: 0;
                                        direction: ltr;
                                    }

                                    .elementor-widget-divider--view-line_icon .elementor-divider-separator,
                                    .elementor-widget-divider--view-line_text .elementor-divider-separator {
                                        align-items: center;
                                    }

                                    .elementor-widget-divider--view-line_icon .elementor-divider-separator:after,
                                    .elementor-widget-divider--view-line_icon .elementor-divider-separator:before,
                                    .elementor-widget-divider--view-line_text .elementor-divider-separator:after,
                                    .elementor-widget-divider--view-line_text .elementor-divider-separator:before {
                                        display: block;
                                        content: '';
                                        border-block-end: 0;
                                        flex-grow: 1;
                                        border-block-start: var(--divider-border-width) var(--divider-border-style) var(--divider-color);
                                    }

                                    .elementor-widget-divider--element-align-left .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type {
                                        flex-grow: 0;
                                        flex-shrink: 100;
                                    }

                                    .elementor-widget-divider--element-align-left .elementor-divider-separator:before {
                                        content: none;
                                    }

                                    .elementor-widget-divider--element-align-left .elementor-divider__element {
                                        margin-left: 0;
                                    }

                                    .elementor-widget-divider--element-align-right .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type {
                                        flex-grow: 0;
                                        flex-shrink: 100;
                                    }

                                    .elementor-widget-divider--element-align-right .elementor-divider-separator:after {
                                        content: none;
                                    }

                                    .elementor-widget-divider--element-align-right .elementor-divider__element {
                                        margin-right: 0;
                                    }

                                    .elementor-widget-divider--element-align-start .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type {
                                        flex-grow: 0;
                                        flex-shrink: 100;
                                    }

                                    .elementor-widget-divider--element-align-start .elementor-divider-separator:before {
                                        content: none;
                                    }

                                    .elementor-widget-divider--element-align-start .elementor-divider__element {
                                        margin-inline-start: 0;
                                    }

                                    .elementor-widget-divider--element-align-end .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type {
                                        flex-grow: 0;
                                        flex-shrink: 100;
                                    }

                                    .elementor-widget-divider--element-align-end .elementor-divider-separator:after {
                                        content: none;
                                    }

                                    .elementor-widget-divider--element-align-end .elementor-divider__element {
                                        margin-inline-end: 0;
                                    }

                                    .elementor-widget-divider:not(.elementor-widget-divider--view-line_text):not(.elementor-widget-divider--view-line_icon) .elementor-divider-separator {
                                        border-block-start: var(--divider-border-width) var(--divider-border-style) var(--divider-color);
                                    }

                                    .elementor-widget-divider--separator-type-pattern {
                                        --divider-border-style: none;
                                    }

                                    .elementor-widget-divider--separator-type-pattern.elementor-widget-divider--view-line .elementor-divider-separator,
                                    .elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:after,
                                    .elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:before,
                                    .elementor-widget-divider--separator-type-pattern:not([class*='elementor-widget-divider--view']) .elementor-divider-separator {
                                        width: 100%;
                                        min-height: var(--divider-pattern-height);
                                        -webkit-mask-size: var(--divider-pattern-size) 100%;
                                        mask-size: var(--divider-pattern-size) 100%;
                                        -webkit-mask-repeat: var(--divider-pattern-repeat);
                                        mask-repeat: var(--divider-pattern-repeat);
                                        background-color: var(--divider-color);
                                        -webkit-mask-image: var(--divider-pattern-url);
                                        mask-image: var(--divider-pattern-url);
                                    }

                                    .elementor-widget-divider--no-spacing {
                                        --divider-pattern-size: auto;
                                    }

                                    .elementor-widget-divider--bg-round {
                                        --divider-pattern-repeat: round;
                                    }

                                    .rtl .elementor-widget-divider .elementor-divider__text {
                                        direction: rtl;
                                    }

                                    .e-con-inner>.elementor-widget-divider,
                                    .e-con>.elementor-widget-divider {
                                        width: var(--container-widget-width, 100%);
                                        --flex-grow: var(--container-widget-flex-grow);
                                    }
                                </style>
                                <div class="elementor-divider">
                                    <span class="elementor-divider-separator"> </span>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-6bed439a elementor-nav-menu__text-align-aside elementor-widget elementor-widget-nav-menu"
                            data-id="6bed439a" data-element_type="widget"
                            data-settings='{"layout":"dropdown","submenu_icon":{"value":"&lt;i class=\"fas fa-caret-down\"&gt;&lt;\/i&gt;","library":"fa-solid"}}'
                            data-widget_type="nav-menu.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-menu-toggle" role="button" tabindex="0"
                                    aria-label="Menu Toggle" aria-expanded="false">
                                    <i aria-hidden="true" role="presentation"
                                        class="elementor-menu-toggle__icon--open eicon-menu-bar"></i><i
                                        aria-hidden="true" role="presentation"
                                        class="elementor-menu-toggle__icon--close eicon-close"></i>
                                    <span class="elementor-screen-only">Menu</span>
                                </div>
                                <nav class="elementor-nav-menu--dropdown elementor-nav-menu__container"
                                    role="navigation" aria-hidden="true">
                                    <ul id="menu-2-6bed439a" class="elementor-nav-menu">
                                        <li
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-63 current_page_item menu-item-544">
                                            <a href="index.html" aria-current="page"
                                                class="elementor-item elementor-item-active" tabindex="-1">Beranda</a>
                                        </li>
                                        <li
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-545">
                                            <a href="#" class="elementor-item elementor-item-anchor"
                                                tabindex="-1">Profile</a>
                                            <ul class="sub-menu elementor-nav-menu--dropdown">
                                                <li
                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-546">
                                                    <a href="ekstrakurikuler/index.html" class="elementor-sub-item"
                                                        tabindex="-1">Ekstrakurikuler</a>
                                                </li>
                                                <li
                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-547">
                                                    <a href="fasilitas/index.html" class="elementor-sub-item"
                                                        tabindex="-1">Fasilitas</a>
                                                </li>
                                                <li
                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-548">
                                                    <a href="guru/index.html" class="elementor-sub-item"
                                                        tabindex="-1">Guru</a>
                                                </li>
                                                <li
                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-549">
                                                    <a href="sambutan-kepala-sekolah/index.html"
                                                        class="elementor-sub-item" tabindex="-1">Sambutan Kepala
                                                        Sekolah</a>
                                                </li>
                                                <li
                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-550">
                                                    <a href="visi-dan-misi/index.html" class="elementor-sub-item"
                                                        tabindex="-1">Visi dan Misi</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-551">
                                            <a href="artikel/index.html" class="elementor-item"
                                                tabindex="-1">Artikel</a>
                                        </li>
                                        <li
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-552">
                                            <a href="#" class="elementor-item elementor-item-anchor"
                                                tabindex="-1">Informasi</a>
                                            <ul class="sub-menu elementor-nav-menu--dropdown">
                                                <li
                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-553">
                                                    <a href="agenda/index.html" class="elementor-sub-item"
                                                        tabindex="-1">Agenda</a>
                                                </li>
                                                <li
                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-554">
                                                    <a href="pengumuman/index.html" class="elementor-sub-item"
                                                        tabindex="-1">Pengumuman</a>
                                                </li>
                                                <li
                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-555">
                                                    <a href="prestasi/index.html" class="elementor-sub-item"
                                                        tabindex="-1">Prestasi</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-556">
                                            <a href="result-ppdb/index.html" class="elementor-item"
                                                tabindex="-1">Result PPDB</a>
                                        </li>
                                        <li
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-557">
                                            <a href="kontak/index.html" class="elementor-item"
                                                tabindex="-1">Kontak</a>
                                        </li>
                                        <li
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-811">
                                            <a href="#" class="elementor-item elementor-item-anchor"
                                                tabindex="-1">Template</a>
                                            <ul class="sub-menu elementor-nav-menu--dropdown">
                                                <li
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-812">
                                                    <a href="https://desa.flymotion.my.id/" class="elementor-sub-item"
                                                        tabindex="-1">CrocoDesa</a>
                                                </li>
                                                <li
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-813">
                                                    <a href="https://liburanyuk.flymotion.my.id/"
                                                        class="elementor-sub-item" tabindex="-1">Travel</a>
                                                </li>
                                                <li
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-814">
                                                    <a href="https://creayoon.flymotion.my.id/"
                                                        class="elementor-sub-item" tabindex="-1">Creayoon School</a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-44a3a6d5 elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                            data-id="44a3a6d5" data-element_type="widget" data-widget_type="divider.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-divider">
                                    <span class="elementor-divider-separator"> </span>
                                </div>
                            </div>
                        </div>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-79527c3a elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="79527c3a" data-element_type="section"
                            data-settings='{"jet_parallax_layout_list":[{"_id":"7380bbb","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-5446103e"
                                    data-id="5446103e" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-4b14661b elementor-widget elementor-widget-heading"
                                            data-id="4b14661b" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <h2 class="elementor-heading-title elementor-size-default">
                                                    Download App Sekolah
                                                </h2>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-1fee75dc elementor-widget elementor-widget-text-editor"
                                            data-id="1fee75dc" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                Nikmati Cara Mudah dan Menyenangkan Ketika Membaca
                                                Buku, Update Informasi Sekolah Hanya Dalam Genggaman
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="elementor-element elementor-element-300c83b6 elementor-widget elementor-widget-image"
                            data-id="300c83b6" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <a href="#">
                                    <img width="320" height="95"
                                        src="wp-content/uploads/2022/03/play-store.png"
                                        class="attachment-full size-full wp-image-118" alt=""
                                        srcset="
                        https://sekolah.flymotion.my.id/wp-content/uploads/2022/03/play-store.png        320w,
                        https://sekolah.flymotion.my.id/wp-content/uploads/2022/03/play-store-300x89.png 300w
                      "
                                        sizes="(max-width: 320px) 100vw, 320px" />
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<style id="elementor-post-dynamic-605">
    .elementor-605 .elementor-element.elementor-element-7f741272.elementor-view-stacked .elementor-icon {
        background-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-7f741272.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-7f741272.elementor-view-default .elementor-icon {
        color: #03626f;
        border-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-7f741272.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-7f741272.elementor-view-default .elementor-icon svg {
        fill: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-3d99d29 .jet-headline__second .jet-headline__label {
        color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-26d8c654.elementor-view-stacked .elementor-icon {
        background-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-26d8c654.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-26d8c654.elementor-view-default .elementor-icon {
        color: #03626f;
        border-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-26d8c654.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-26d8c654.elementor-view-default .elementor-icon svg {
        fill: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-308510b.elementor-view-stacked .elementor-icon {
        background-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-308510b.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-308510b.elementor-view-default .elementor-icon {
        color: #03626f;
        border-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-308510b.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-308510b.elementor-view-default .elementor-icon svg {
        fill: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-827e340 .jet-headline__second .jet-headline__label {
        color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-3950a2eb.elementor-view-stacked .elementor-icon {
        background-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-3950a2eb.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-3950a2eb.elementor-view-default .elementor-icon {
        color: #03626f;
        border-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-3950a2eb.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-3950a2eb.elementor-view-default .elementor-icon svg {
        fill: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-12762f17.elementor-view-stacked .elementor-icon {
        background-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-12762f17.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-12762f17.elementor-view-default .elementor-icon {
        color: #03626f;
        border-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-12762f17.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-12762f17.elementor-view-default .elementor-icon svg {
        fill: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-df3b3fd.elementor-view-stacked .elementor-icon {
        background-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-df3b3fd.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-df3b3fd.elementor-view-default .elementor-icon {
        color: #03626f;
        border-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-df3b3fd.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-df3b3fd.elementor-view-default .elementor-icon svg {
        fill: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-519e8305.elementor-view-stacked .elementor-icon {
        background-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-519e8305.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-519e8305.elementor-view-default .elementor-icon {
        color: #03626f;
        border-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-519e8305.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-519e8305.elementor-view-default .elementor-icon svg {
        fill: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-6c4392bf.elementor-view-stacked .elementor-icon {
        background-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-6c4392bf.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-6c4392bf.elementor-view-default .elementor-icon {
        color: #03626f;
        border-color: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-6c4392bf.elementor-view-framed .elementor-icon,
    .elementor-605 .elementor-element.elementor-element-6c4392bf.elementor-view-default .elementor-icon svg {
        fill: #03626f;
    }

    .elementor-605 .elementor-element.elementor-element-7d691a5f .elementor-button {
        background-color: #03626f;
    }
</style>
<div data-elementor-type="popup" data-elementor-id="605" class="elementor elementor-605 elementor-location-popup"
    data-elementor-settings='{"entrance_animation":"fadeInDown","entrance_animation_mobile":"slideInUp","exit_animation":"fadeInDown","exit_animation_mobile":"slideInUp","entrance_animation_duration":{"unit":"px","size":0.5,"sizes":[]},"timing":[]}'>
    <div class="elementor-section-wrap">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-417ca45d elementor-hidden-desktop elementor-hidden-tablet elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="417ca45d" data-element_type="section"
            data-settings='{"background_background":"classic","stretch_section":"section-stretched","jet_parallax_layout_list":[{"_id":"57bdfd9","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-56104928"
                    data-id="56104928" data-element_type="column"
                    data-settings='{"background_background":"classic"}'>
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-31052ad6 elementor-widget elementor-widget-image"
                            data-id="31052ad6" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <a href="index.html">
                                    <img width="333" height="87" src="{{ asset($sekolah->logo) }}"
                                        class="attachment-full size-full wp-image-1215" alt=""
                                        sizes="(max-width: 333px) 100vw, 333px" />
                                </a>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-c778c6b elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                            data-id="c778c6b" data-element_type="widget" data-widget_type="divider.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-divider">
                                    <span class="elementor-divider-separator"> </span>
                                </div>
                            </div>
                        </div>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-75544734 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="75544734" data-element_type="section"
                            data-settings='{"jet_parallax_layout_list":[{"_id":"26e1e7f","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-7694a1e9"
                                    data-id="7694a1e9" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-7f741272 elementor-view-default elementor-widget elementor-widget-icon"
                                            data-id="7f741272" data-element_type="widget"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <a class="elementor-icon" href="#">
                                                        <i aria-hidden="true" class="fas fa-phone-alt"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6fcce09c"
                                    data-id="6fcce09c" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-3d99d29 elementor-widget elementor-widget-jet-headline"
                                            data-id="3d99d29" data-element_type="widget"
                                            data-widget_type="jet-headline.default">
                                            <div class="elementor-widget-container">
                                                <h2 class="jet-headline jet-headline--direction-horizontal">
                                                    <span class="jet-headline__part jet-headline__first"><span
                                                            class="jet-headline__label">Hubungi kami di :
                                                        </span></span><span
                                                        class="jet-headline__part jet-headline__second"><span
                                                            class="jet-headline__label">{{ $sekolah->phone }}</span></span>
                                                </h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-1ac45a47"
                                    data-id="1ac45a47" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-26d8c654 elementor-view-default elementor-widget elementor-widget-icon"
                                            data-id="26d8c654" data-element_type="widget"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <a class="elementor-icon" href="#">
                                                        <i aria-hidden="true" class="fas fa-angle-right"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-4f60f0a9 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="4f60f0a9" data-element_type="section"
                            data-settings='{"jet_parallax_layout_list":[{"_id":"26e1e7f","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-141c9b3d"
                                    data-id="141c9b3d" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-308510b elementor-view-default elementor-widget elementor-widget-icon"
                                            data-id="308510b" data-element_type="widget"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <a class="elementor-icon" href="mailto:{{ $sekolah->email }}">
                                                        <i aria-hidden="true" class="fas fa-mail-bulk"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-5b8d443a"
                                    data-id="5b8d443a" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-827e340 elementor-widget elementor-widget-jet-headline"
                                            data-id="827e340" data-element_type="widget"
                                            data-widget_type="jet-headline.default">
                                            <div class="elementor-widget-container">
                                                <h2 class="jet-headline jet-headline--direction-horizontal">
                                                    <span class="jet-headline__part jet-headline__first"><span
                                                            class="jet-headline__label">Kirim email ke
                                                            kami </span></span><span
                                                        class="jet-headline__part jet-headline__second"><span
                                                            class="jet-headline__label">
                                                            {{ $sekolah->email }}</span></span>
                                                </h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-5f82f414"
                                    data-id="5f82f414" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-3950a2eb elementor-view-default elementor-widget elementor-widget-icon"
                                            data-id="3950a2eb" data-element_type="widget"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <a class="elementor-icon" href="mailto:{{ $sekolah->email }}">
                                                        <i aria-hidden="true" class="fas fa-angle-right"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-7ed2e8eb elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="7ed2e8eb" data-element_type="section"
                            data-settings='{"jet_parallax_layout_list":[{"_id":"26e1e7f","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-76d1dc5d"
                                    data-id="76d1dc5d" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-12762f17 elementor-view-default elementor-widget elementor-widget-icon"
                                            data-id="12762f17" data-element_type="widget"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <a class="elementor-icon"
                                                        href="https://wa.me/{{ $sekolah->phone }}">
                                                        <i aria-hidden="true" class="fab fa-whatsapp"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-1bf62ceb"
                                    data-id="1bf62ceb" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-596fa7bd elementor-widget elementor-widget-heading"
                                            data-id="596fa7bd" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <h2 class="elementor-heading-title elementor-size-default">
                                                    <a href="https://wa.me/{{ $sekolah->phone }}">Kirim form pertanyaan
                                                        melalui
                                                        WhatsApp</a>
                                                </h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2c86371"
                                    data-id="2c86371" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-df3b3fd elementor-view-default elementor-widget elementor-widget-icon"
                                            data-id="df3b3fd" data-element_type="widget"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <a class="elementor-icon"
                                                        href="https://wa.me/{{ $sekolah->phone }}">
                                                        <i aria-hidden="true" class="fas fa-angle-right"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        {{-- <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-7e4f36 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="7e4f36" data-element_type="section"
                            data-settings='{"jet_parallax_layout_list":[{"_id":"26e1e7f","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-562e12f5"
                                    data-id="562e12f5" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-519e8305 elementor-view-default elementor-widget elementor-widget-icon"
                                            data-id="519e8305" data-element_type="widget"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <a class="elementor-icon" href="result-ppdb/index.html">
                                                        <i aria-hidden="true" class="fas fa-user-graduate"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-1b8481e9"
                                    data-id="1b8481e9" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-60cfd628 elementor-widget elementor-widget-heading"
                                            data-id="60cfd628" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <h2 class="elementor-heading-title elementor-size-default">
                                                    <a href="result-ppdb/index.html">Lihat Hasil PPDB Disini</a>
                                                </h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-1dcd3ca1"
                                    data-id="1dcd3ca1" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-6c4392bf elementor-view-default elementor-widget elementor-widget-icon"
                                            data-id="6c4392bf" data-element_type="widget"
                                            data-widget_type="icon.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-icon-wrapper">
                                                    <a class="elementor-icon" href="result-ppdb/index.html">
                                                        <i aria-hidden="true" class="fas fa-angle-right"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section> --}}
                        <div class="elementor-element elementor-element-3f5482ef elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                            data-id="3f5482ef" data-element_type="widget" data-widget_type="divider.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-divider">
                                    <span class="elementor-divider-separator"> </span>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-7d691a5f elementor-mobile-align-justify elementor-align-justify elementor-widget elementor-widget-button"
                            data-id="7d691a5f" data-element_type="widget" data-widget_type="button.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-button-wrapper">
                                    <a class="elementor-button elementor-button-link elementor-size-sm"
                                        href="#elementor-action%3Aaction%3Dpopup%3Aclose%26settings%3DeyJkb19ub3Rfc2hvd19hZ2FpbiI6IiJ9">
                                        <span class="elementor-button-content-wrapper">
                                            <span class="elementor-button-text">Tutup</span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<style id="elementor-post-dynamic-565">
    .elementor-565 .elementor-element.elementor-element-7ae48458 .elementor-field-group>a:hover {
        color: #03626f;
    }

    .elementor-565 .elementor-element.elementor-element-7ae48458 .elementor-button {
        background-color: #03626f;
    }

    .elementor-565 .elementor-element.elementor-element-7ae48458 .elementor-button:hover {
        background-color: #ffa800;
    }
</style>
<div data-elementor-type="popup" data-elementor-id="565" class="elementor elementor-565 elementor-location-popup"
    data-elementor-settings='{"entrance_animation":"fadeInDown","exit_animation":"fadeInDown","entrance_animation_mobile":"slideInUp","exit_animation_mobile":"slideInUp","entrance_animation_duration":{"unit":"px","size":0.5,"sizes":[]},"timing":[]}'>
    <div class="elementor-section-wrap">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-6866c4eb elementor-hidden-desktop elementor-hidden-tablet elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="6866c4eb" data-element_type="section"
            data-settings='{"background_background":"classic","stretch_section":"section-stretched","jet_parallax_layout_list":[{"_id":"57bdfd9","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-42044f08"
                    data-id="42044f08" data-element_type="column"
                    data-settings='{"background_background":"classic"}'>
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-1a728b58 elementor-widget elementor-widget-image"
                            data-id="1a728b58" data-element_type="widget" data-widget_type="image.default">
                            <div class="elementor-widget-container">
                                <a href="index.html">
                                    <img width="333" height="87" src="{{ asset($sekolah->logo) }}"
                                        class="attachment-full size-full wp-image-1215" alt=""
                                        sizes="(max-width: 333px) 100vw, 333px" />
                                </a>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-54f1b37 elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                            data-id="54f1b37" data-element_type="widget" data-widget_type="divider.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-divider">
                                    <span class="elementor-divider-separator"> </span>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-7ae48458 elementor-mobile-button-align-stretch elementor-widget elementor-widget-login"
                            data-id="7ae48458" data-element_type="widget" data-widget_type="login.default">
                            <div class="elementor-widget-container">
                                <style>
                                    /*! elementor-pro - v3.7.7 - 20-09-2022 */
                                    .elementor-button.elementor-hidden,
                                    .elementor-hidden {
                                        display: none;
                                    }

                                    .e-form__step {
                                        width: 100%;
                                    }

                                    .e-form__step:not(.elementor-hidden) {
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex;
                                        -ms-flex-wrap: wrap;
                                        flex-wrap: wrap;
                                    }

                                    .e-form__buttons {
                                        -ms-flex-wrap: wrap;
                                        flex-wrap: wrap;
                                    }

                                    .e-form__buttons,
                                    .e-form__buttons__wrapper {
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex;
                                    }

                                    .e-form__indicators {
                                        -webkit-box-pack: justify;
                                        -ms-flex-pack: justify;
                                        justify-content: space-between;
                                        -ms-flex-wrap: nowrap;
                                        flex-wrap: nowrap;
                                        font-size: 13px;
                                        margin-bottom: var(--e-form-steps-indicators-spacing);
                                    }

                                    .e-form__indicators,
                                    .e-form__indicators__indicator {
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex;
                                        -webkit-box-align: center;
                                        -ms-flex-align: center;
                                        align-items: center;
                                    }

                                    .e-form__indicators__indicator {
                                        -webkit-box-orient: vertical;
                                        -webkit-box-direction: normal;
                                        -ms-flex-direction: column;
                                        flex-direction: column;
                                        -webkit-box-pack: center;
                                        -ms-flex-pack: center;
                                        justify-content: center;
                                        -ms-flex-preferred-size: 0;
                                        flex-basis: 0;
                                        padding: 0 var(--e-form-steps-divider-gap);
                                    }

                                    .e-form__indicators__indicator__progress {
                                        width: 100%;
                                        position: relative;
                                        background-color: var(--e-form-steps-indicator-progress-background-color);
                                        border-radius: var(--e-form-steps-indicator-progress-border-radius);
                                        overflow: hidden;
                                    }

                                    .e-form__indicators__indicator__progress__meter {
                                        width: var(--e-form-steps-indicator-progress-meter-width,
                                                0);
                                        height: var(--e-form-steps-indicator-progress-height);
                                        line-height: var(--e-form-steps-indicator-progress-height);
                                        padding-right: 15px;
                                        border-radius: var(--e-form-steps-indicator-progress-border-radius);
                                        background-color: var(--e-form-steps-indicator-progress-color);
                                        color: var(--e-form-steps-indicator-progress-meter-color);
                                        text-align: right;
                                        -webkit-transition: width 0.1s linear;
                                        -o-transition: width 0.1s linear;
                                        transition: width 0.1s linear;
                                    }

                                    .e-form__indicators__indicator:first-child {
                                        padding-left: 0;
                                    }

                                    .e-form__indicators__indicator:last-child {
                                        padding-right: 0;
                                    }

                                    .e-form__indicators__indicator--state-inactive {
                                        color: var(--e-form-steps-indicator-inactive-primary-color,
                                                #c2cbd2);
                                    }

                                    .e-form__indicators__indicator--state-inactive [class*='indicator--shape-']:not(.e-form__indicators__indicator--shape-none) {
                                        background-color: var(--e-form-steps-indicator-inactive-secondary-color,
                                                #fff);
                                    }

                                    .e-form__indicators__indicator--state-inactive object,
                                    .e-form__indicators__indicator--state-inactive svg {
                                        fill: var(--e-form-steps-indicator-inactive-primary-color,
                                                #c2cbd2);
                                    }

                                    .e-form__indicators__indicator--state-active {
                                        color: var(--e-form-steps-indicator-active-primary-color,
                                                #39b54a);
                                        border-color: var(--e-form-steps-indicator-active-secondary-color,
                                                #fff);
                                    }

                                    .e-form__indicators__indicator--state-active [class*='indicator--shape-']:not(.e-form__indicators__indicator--shape-none) {
                                        background-color: var(--e-form-steps-indicator-active-secondary-color,
                                                #fff);
                                    }

                                    .e-form__indicators__indicator--state-active object,
                                    .e-form__indicators__indicator--state-active svg {
                                        fill: var(--e-form-steps-indicator-active-primary-color,
                                                #39b54a);
                                    }

                                    .e-form__indicators__indicator--state-completed {
                                        color: var(--e-form-steps-indicator-completed-secondary-color,
                                                #fff);
                                    }

                                    .e-form__indicators__indicator--state-completed [class*='indicator--shape-']:not(.e-form__indicators__indicator--shape-none) {
                                        background-color: var(--e-form-steps-indicator-completed-primary-color,
                                                #39b54a);
                                    }

                                    .e-form__indicators__indicator--state-completed .e-form__indicators__indicator__label {
                                        color: var(--e-form-steps-indicator-completed-primary-color,
                                                #39b54a);
                                    }

                                    .e-form__indicators__indicator--state-completed .e-form__indicators__indicator--shape-none {
                                        color: var(--e-form-steps-indicator-completed-primary-color,
                                                #39b54a);
                                        background-color: initial;
                                    }

                                    .e-form__indicators__indicator--state-completed object,
                                    .e-form__indicators__indicator--state-completed svg {
                                        fill: var(--e-form-steps-indicator-completed-secondary-color,
                                                #fff);
                                    }

                                    .e-form__indicators__indicator__icon {
                                        width: var(--e-form-steps-indicator-padding, 30px);
                                        height: var(--e-form-steps-indicator-padding, 30px);
                                        font-size: var(--e-form-steps-indicator-icon-size);
                                        border-width: 1px;
                                        border-style: solid;
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex;
                                        -webkit-box-pack: center;
                                        -ms-flex-pack: center;
                                        justify-content: center;
                                        -webkit-box-align: center;
                                        -ms-flex-align: center;
                                        align-items: center;
                                        overflow: hidden;
                                        margin-bottom: 10px;
                                    }

                                    .e-form__indicators__indicator__icon img,
                                    .e-form__indicators__indicator__icon object,
                                    .e-form__indicators__indicator__icon svg {
                                        width: var(--e-form-steps-indicator-icon-size);
                                        height: auto;
                                    }

                                    .e-form__indicators__indicator__icon .e-font-icon-svg {
                                        height: 1em;
                                    }

                                    .e-form__indicators__indicator__number {
                                        width: var(--e-form-steps-indicator-padding, 30px);
                                        height: var(--e-form-steps-indicator-padding, 30px);
                                        border-width: 1px;
                                        border-style: solid;
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex;
                                        -webkit-box-pack: center;
                                        -ms-flex-pack: center;
                                        justify-content: center;
                                        -webkit-box-align: center;
                                        -ms-flex-align: center;
                                        align-items: center;
                                        margin-bottom: 10px;
                                    }

                                    .e-form__indicators__indicator--shape-circle {
                                        border-radius: 50%;
                                    }

                                    .e-form__indicators__indicator--shape-square {
                                        border-radius: 0;
                                    }

                                    .e-form__indicators__indicator--shape-rounded {
                                        border-radius: 5px;
                                    }

                                    .e-form__indicators__indicator--shape-none {
                                        border: 0;
                                    }

                                    .e-form__indicators__indicator__label {
                                        text-align: center;
                                    }

                                    .e-form__indicators__indicator__separator {
                                        width: 100%;
                                        height: var(--e-form-steps-divider-width);
                                        background-color: #c2cbd2;
                                    }

                                    .e-form__indicators--type-icon,
                                    .e-form__indicators--type-icon_text,
                                    .e-form__indicators--type-number,
                                    .e-form__indicators--type-number_text {
                                        -webkit-box-align: start;
                                        -ms-flex-align: start;
                                        align-items: flex-start;
                                    }

                                    .e-form__indicators--type-icon .e-form__indicators__indicator__separator,
                                    .e-form__indicators--type-icon_text .e-form__indicators__indicator__separator,
                                    .e-form__indicators--type-number .e-form__indicators__indicator__separator,
                                    .e-form__indicators--type-number_text .e-form__indicators__indicator__separator {
                                        margin-top: calc(var(--e-form-steps-indicator-padding, 30px) / 2 - var(--e-form-steps-divider-width, 1px) / 2);
                                    }

                                    .elementor-field-type-hidden {
                                        display: none;
                                    }

                                    .elementor-field-type-html {
                                        display: inline-block;
                                    }

                                    .elementor-login .elementor-lost-password,
                                    .elementor-login .elementor-remember-me {
                                        font-size: 0.85em;
                                    }

                                    .elementor-field-type-recaptcha_v3 .elementor-field-label {
                                        display: none;
                                    }

                                    .elementor-field-type-recaptcha_v3 .grecaptcha-badge {
                                        z-index: 1;
                                    }

                                    .elementor-button .elementor-form-spinner {
                                        -webkit-box-ordinal-group: 4;
                                        -ms-flex-order: 3;
                                        order: 3;
                                    }

                                    .elementor-form .elementor-button>span {
                                        display: -webkit-box;
                                        display: -ms-flexbox;
                                        display: flex;
                                        -webkit-box-pack: center;
                                        -ms-flex-pack: center;
                                        justify-content: center;
                                        -webkit-box-align: center;
                                        -ms-flex-align: center;
                                        align-items: center;
                                    }

                                    .elementor-form .elementor-button .elementor-button-text {
                                        white-space: normal;
                                        -webkit-box-flex: 0;
                                        -ms-flex-positive: 0;
                                        flex-grow: 0;
                                    }

                                    .elementor-form .elementor-button svg {
                                        height: auto;
                                    }

                                    .elementor-form .elementor-button .e-font-icon-svg {
                                        height: 1em;
                                    }

                                    .elementor-select-wrapper .select-caret-down-wrapper {
                                        position: absolute;
                                        top: 50%;
                                        -webkit-transform: translateY(-50%);
                                        -ms-transform: translateY(-50%);
                                        transform: translateY(-50%);
                                        inset-inline-end: 10px;
                                        pointer-events: none;
                                        font-size: 11px;
                                    }

                                    .elementor-select-wrapper .select-caret-down-wrapper svg {
                                        display: unset;
                                        width: 1em;
                                        aspect-ratio: unset;
                                        fill: currentColor;
                                    }

                                    .elementor-select-wrapper .select-caret-down-wrapper i {
                                        font-size: 19px;
                                        line-height: 2;
                                    }

                                    .elementor-select-wrapper.remove-before:before {
                                        content: '' !important;
                                    }
                                </style>
                                <form action="{{ route('login') }}">
                                    @csrf
                                    <div class="elementor-form-fields-wrapper">
                                        <div
                                            class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required">
                                            <input size="1" type="text" name="email" placeholder="email"
                                                id="email" placeholder=""
                                                class="elementor-field elementor-field-textual elementor-size-sm" />
                                        </div>
                                        <div
                                            class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required">
                                            <input size="1" type="password" placeholder="*****"
                                                name="password" id="password" placeholder=""
                                                class="elementor-field elementor-field-textual elementor-size-sm" />
                                        </div>

                                        <div
                                            class="elementor-field-group elementor-column elementor-field-type-submit elementor-col-100">
                                            <button type="submit" class="elementor-size-sm elementor-button"
                                                name="wp-submit">
                                                <span class="elementor-button-text">Masuk</span>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-4f4abd0c elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="4f4abd0c" data-element_type="section"
                            data-settings='{"jet_parallax_layout_list":[{"_id":"7380bbb","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-43ddb988"
                                    data-id="43ddb988" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-3fe278e6 elementor-widget elementor-widget-heading"
                                            data-id="3fe278e6" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <h2 class="elementor-heading-title elementor-size-default">
                                                    Download App Sekolah
                                                </h2>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-4f7771bf elementor-widget elementor-widget-text-editor"
                                            data-id="4f7771bf" data-element_type="widget"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                Nikmati Cara Mudah dan Menyenangkan Ketika Membaca
                                                Buku, Update Informasi Sekolah Hanya Dalam Genggaman
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-39680130 elementor-widget elementor-widget-image"
                                            data-id="39680130" data-element_type="widget"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <a href="#">
                                                    <img width="320" height="95"
                                                        src="wp-content/uploads/2022/03/play-store.png"
                                                        class="attachment-full size-full wp-image-118" alt=""
                                                        srcset="
                                https://sekolah.flymotion.my.id/wp-content/uploads/2022/03/play-store.png        320w,
                                https://sekolah.flymotion.my.id/wp-content/uploads/2022/03/play-store-300x89.png 300w
                              "
                                                        sizes="(max-width: 320px) 100vw, 320px" />
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
