<script type="text/html" id="tmpl-jet-ajax-search-results-item">
    <div class="jet-ajax-search__results-item">
      <a
        class="jet-ajax-search__item-link"
        href="#"
        target="#"
      >
        <img src="#"/>
        <div class="jet-ajax-search__item-content-wrapper">
          judul
          <div class="jet-ajax-search__item-title">judul</div>
          -
          <div class="jet-ajax-search__item-content">konten</div>
          - 5 10000
        </div>
      </a>
    </div>
  </script>
<link rel="stylesheet" id="elementor-post-596-css"
    href="{{ asset('wp-content/uploads/elementor/css/post-596c416.css?ver=1717311691') }}" media="all" />
<link rel="stylesheet" id="elementor-post-605-css"
    href="{{ asset('wp-content/uploads/elementor/css/post-6055d1f.css?ver=1717311692') }}" media="all" />
<link rel="stylesheet" id="elementor-post-565-css"
    href="{{ asset('wp-content/uploads/elementor/css/post-5655d1f.css?ver=1717311692') }}" media="all" />
<link rel="stylesheet" id="e-animations-css"
    href="{{ asset('wp-content/plugins/elementor/assets/lib/animations/animations.min3cad.css?ver=3.21.8') }}"
    media="all" />
<script src="{{ asset('wp-content/themes/hello-elementor/assets/js/hello-frontend.min41fe.js?ver=3.0.1') }}"
    id="hello-theme-frontend-js"></script>
<script src="{{ asset('wp-content/plugins/elementor-pro/assets/lib/instant-page/instant-page.minac9e.js?ver=3.7.7') }}"
    id="instant-page-js"></script>
<script src="{{ asset('wp-includes/js/jquery/jquery.minf43b.js?ver=3.7.1') }}" id="jquery-core-js"></script>
<script src="{{ asset('wp-includes/js/jquery/jquery-migrate.min5589.js?ver=3.4.1') }}" id="jquery-migrate-js"></script>
<script
    src="{{ asset('wp-content/plugins/elementor-pro/assets/lib/smartmenus/jquery.smartmenus.minf269.js?ver=1.0.1') }}"
    id="smartmenus-js"></script>
<script src="{{ asset('wp-includes/js/imagesloaded.minbb93.js?ver=5.0.0') }}" id="imagesloaded-js"></script>
<script src="{{ asset('wp-content/plugins/jet-elements/assets/js/lib/slick/slick.minc245.js?ver=1.8.1') }}"
    id="jet-slick-js"></script>
<script id="jet-engine-frontend-js-extra">
    var JetEngineSettings = {
        ajaxurl: 'https:\/\/sekolah.flymotion.my.id\/wp-admin\/admin-ajax.php',
        ajaxlisting: 'https:\/\/sekolah.flymotion.my.id\/?nocache=1723531181',
        mapPopupTimeout: '400',
        addedPostCSS: [
            '707',
            '14',
            '12',
            '18',
            '20',
            '1302',
            '19',
            '13',
            '16',
            '942',
            '1310',
            '15',
        ],
    }
</script>
<script src="{{ asset('wp-content/plugins/jet-engine/assets/js/frontendd731.js?ver=2.11.5') }}"
    id="jet-engine-frontend-js"></script>
<script src="{{ asset('wp-content/plugins/jet-engine/assets/lib/slick/slick.minc245.js?ver=1.8.1') }}"
    id="jquery-slick-js"></script>
<script src="{{ asset('wp-includes/js/hoverIntent.min3e5a.js?ver=1.10.2') }}" id="hoverIntent-js"></script>
<script src="{{ asset('wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.minac9e.js?ver=3.7.7') }}"
    id="elementor-pro-webpack-runtime-js"></script>
<script src="{{ asset('wp-content/plugins/elementor/assets/js/webpack.runtime.min3cad.js?ver=3.21.8') }}"
    id="elementor-webpack-runtime-js"></script>
<script src="{{ asset('wp-content/plugins/elementor/assets/js/frontend-modules.min3cad.js?ver=3.21.8') }}"
    id="elementor-frontend-modules-js"></script>
<script src="{{ asset('wp-includes/js/dist/vendor/wp-polyfill-inert.min0226.js?ver=3.1.2') }}"
    id="wp-polyfill-inert-js"></script>
<script src="{{ asset('wp-includes/js/dist/vendor/regenerator-runtime.min6c85.js?ver=0.14.0') }}"
    id="regenerator-runtime-js"></script>
<script src="{{ asset('wp-includes/js/dist/vendor/wp-polyfill.min2c7c.js?ver=3.15.0') }}" id="wp-polyfill-js"></script>
<script src="{{ asset('wp-includes/js/dist/hooks.min2757.js?ver=2810c76e705dd1a53b18') }}" id="wp-hooks-js"></script>
<script src="{{ asset('wp-includes/js/dist/i18n.minc33c.js?ver=5e580eb46a90c2b997e6') }}" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
    wp.i18n.setLocaleData({
        'text direction\u0004ltr': ['ltr']
    })
</script>
<script id="elementor-pro-frontend-js-before">
    var ElementorProFrontendConfig = {
        ajaxurl: 'https:\/\/sekolah.flymotion.my.id\/wp-admin\/admin-ajax.php',
        nonce: 'e7ac8faa31',
        urls: {
            assets: 'https:\/\/sekolah.flymotion.my.id\/wp-content\/plugins\/elementor-pro\/assets\/',
            rest: 'https:\/\/sekolah.flymotion.my.id\/wp-json\/',
        },
        shareButtonsNetworks: {
            facebook: {
                title: 'Facebook',
                has_counter: true
            },
            twitter: {
                title: 'Twitter'
            },
            linkedin: {
                title: 'LinkedIn',
                has_counter: true
            },
            pinterest: {
                title: 'Pinterest',
                has_counter: true
            },
            reddit: {
                title: 'Reddit',
                has_counter: true
            },
            vk: {
                title: 'VK',
                has_counter: true
            },
            odnoklassniki: {
                title: 'OK',
                has_counter: true
            },
            tumblr: {
                title: 'Tumblr'
            },
            digg: {
                title: 'Digg'
            },
            skype: {
                title: 'Skype'
            },
            stumbleupon: {
                title: 'StumbleUpon',
                has_counter: true
            },
            mix: {
                title: 'Mix'
            },
            telegram: {
                title: 'Telegram'
            },
            pocket: {
                title: 'Pocket',
                has_counter: true
            },
            xing: {
                title: 'XING',
                has_counter: true
            },
            whatsapp: {
                title: 'WhatsApp'
            },
            email: {
                title: 'Email'
            },
            print: {
                title: 'Print'
            },
        },
        facebook_sdk: {
            lang: 'id_ID',
            app_id: ''
        },
        lottie: {
            defaultAnimationUrl: 'https:\/\/sekolah.flymotion.my.id\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json',
        },
    }
</script>
<script src="{{ asset('wp-content/plugins/elementor-pro/assets/js/frontend.minac9e.js?ver=3.7.7') }}"
    id="elementor-pro-frontend-js"></script>
<script src="{{ asset('wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2') }}"
    id="elementor-waypoints-js"></script>
<script src="{{ asset('wp-includes/js/jquery/ui/core.min3f14.js?ver=1.13.2') }}" id="jquery-ui-core-js"></script>
<script id="elementor-frontend-js-before">
    var elementorFrontendConfig = {
        environmentMode: {
            edit: false,
            wpPreview: false,
            isScriptDebug: false,
        },
        i18n: {
            shareOnFacebook: 'Bagikan di Facebook',
            shareOnTwitter: 'Bagikan di Twitter',
            pinIt: 'Buat Pin',
            download: 'Unduh',
            downloadImage: 'Unduh gambar',
            fullscreen: 'Layar Penuh',
            zoom: 'Perbesar',
            share: 'Bagikan',
            playVideo: 'Putar Video',
            previous: 'Sebelumnya',
            next: 'Selanjutnya',
            close: 'Tutup',
            a11yCarouselWrapperAriaLabel: 'Carousel | Horizontal scrolling: Arrow Left & Right',
            a11yCarouselPrevSlideMessage: 'Slide sebelumnya',
            a11yCarouselNextSlideMessage: 'Slide selanjutnya',
            a11yCarouselFirstSlideMessage: 'This is the first slide',
            a11yCarouselLastSlideMessage: 'This is the last slide',
            a11yCarouselPaginationBulletMessage: 'Go to slide',
        },
        is_rtl: false,
        breakpoints: {
            xs: 0,
            sm: 480,
            md: 768,
            lg: 1025,
            xl: 1440,
            xxl: 1600
        },
        responsive: {
            breakpoints: {
                mobile: {
                    label: 'Mobile Portrait',
                    value: 767,
                    default_value: 767,
                    direction: 'max',
                    is_enabled: true,
                },
                mobile_extra: {
                    label: 'Mobile Landscape',
                    value: 880,
                    default_value: 880,
                    direction: 'max',
                    is_enabled: false,
                },
                tablet: {
                    label: 'Tablet Portrait',
                    value: 1024,
                    default_value: 1024,
                    direction: 'max',
                    is_enabled: true,
                },
                tablet_extra: {
                    label: 'Tablet Landscape',
                    value: 1200,
                    default_value: 1200,
                    direction: 'max',
                    is_enabled: false,
                },
                laptop: {
                    label: 'Laptop',
                    value: 1366,
                    default_value: 1366,
                    direction: 'max',
                    is_enabled: false,
                },
                widescreen: {
                    label: 'Layar lebar',
                    value: 2400,
                    default_value: 2400,
                    direction: 'min',
                    is_enabled: false,
                },
            },
        },
        version: '3.21.8',
        is_static: false,
        experimentalFeatures: {
            e_optimized_assets_loading: true,
            e_optimized_css_loading: true,
            additional_custom_breakpoints: true,
            e_swiper_latest: true,
            container_grid: true,
            theme_builder_v2: true,
            'hello-theme-header-footer': true,
            home_screen: true,
            'ai-layout': true,
            'landing-pages': true,
            'page-transitions': true,
            notes: true,
            'form-submissions': true,
            e_scroll_snap: true,
        },
        urls: {
            assets: 'https:\/\/sekolah.flymotion.my.id\/wp-content\/plugins\/elementor\/assets\/',
        },
        swiperClass: 'swiper',
        settings: {
            page: [],
            editorPreferences: []
        },
        kit: {
            body_background_background: 'classic',
            active_breakpoints: ['viewport_mobile', 'viewport_tablet'],
            global_image_lightbox: 'yes',
            lightbox_enable_counter: 'yes',
            lightbox_enable_fullscreen: 'yes',
            lightbox_enable_zoom: 'yes',
            lightbox_enable_share: 'yes',
            lightbox_title_src: 'title',
            lightbox_description_src: 'description',
            hello_header_logo_type: 'title',
            hello_header_menu_layout: 'horizontal',
        },
        post: {
            id: 63,
            title: 'Sekolah%20Template%20%E2%80%93%20Crocoblock%20x%20Elementor',
            excerpt: '',
            featuredImage: false,
        },
    }
</script>
<script src="{{ asset('wp-content/plugins/elementor/assets/js/frontend.min3cad.js?ver=3.21.8') }}"
    id="elementor-frontend-js"></script>
<script src="{{ asset('wp-content/plugins/elementor-pro/assets/js/elements-handlers.minac9e.js?ver=3.7.7') }}"
    id="pro-elements-handlers-js"></script>
<script id="jet-blocks-js-extra">
    var JetHamburgerPanelSettings = {
        ajaxurl: 'https:\/\/sekolah.flymotion.my.id\/wp-admin\/admin-ajax.php',
        isMobile: 'false',
        templateApiUrl: 'https:\/\/sekolah.flymotion.my.id\/wp-json\/jet-blocks-api\/v1\/elementor-template',
        devMode: 'false',
    }
</script>
<script src="{{ asset('wp-content/plugins/jet-blocks/assets/js/jet-blocks.min6f3e.js?ver=1.3.0') }}"
    id="jet-blocks-js"></script>
<script id="jet-elements-js-extra">
    var jetElements = {
        ajaxUrl: 'https:\/\/sekolah.flymotion.my.id\/wp-admin\/admin-ajax.php',
        isMobile: 'false',
        templateApiUrl: 'https:\/\/sekolah.flymotion.my.id\/wp-json\/jet-elements-api\/v1\/elementor-template',
        devMode: 'false',
        messages: {
            invalidMail: 'Please specify a valid e-mail'
        },
    }
</script>
<script src="{{ asset('wp-content/plugins/jet-elements/assets/js/jet-elements.min61da.js?ver=2.6.2') }}"
    id="jet-elements-js"></script>
<script src="{{ asset('wp-content/plugins/jet-elements/assets/js/lib/anime-js/anime.min3601.js?ver=2.2.0') }}"
    id="jet-anime-js-js"></script>
<script id="jet-popup-frontend-js-extra">
    var jetPopupData = {
        elements_data: {
            sections: [],
            columns: [],
            widgets: []
        },
        version: '1.5.5',
        ajax_url: 'https:\/\/sekolah.flymotion.my.id\/wp-admin\/admin-ajax.php',
    }
</script>
<script src="{{ asset('wp-content/plugins/jet-popup/assets/js/jet-popup-frontend2846.js?ver=1.5.5') }}"
    id="jet-popup-frontend-js"></script>
<script id="jet-tabs-frontend-js-extra">
    var JetTabsSettings = {
        ajaxurl: 'https:\/\/sekolah.flymotion.my.id\/wp-admin\/admin-ajax.php',
        isMobile: 'false',
        templateApiUrl: 'https:\/\/sekolah.flymotion.my.id\/wp-json\/jet-tabs-api\/v1\/elementor-template',
        devMode: 'false',
    }
</script>
<script src="{{ asset('wp-content/plugins/jet-tabs/assets/js/jet-tabs-frontend.min202b.js?ver=2.1.15') }}"
    id="jet-tabs-frontend-js"></script>
<script id="jet-tricks-frontend-js-extra">
    var JetTricksSettings = {
        elements_data: {
            sections: [],
            columns: [],
            widgets: []
        },
    }
</script>
<script src="{{ asset('wp-content/plugins/jet-tricks/assets/js/jet-tricks-frontend2fca.js?ver=1.4.0') }}"
    id="jet-tricks-frontend-js"></script>
<script src="{{ asset('wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.minac9e.js?ver=3.7.7') }}"
    id="e-sticky-js"></script>
<script src="{{ asset('wp-includes/js/underscore.mind584.js?ver=1.13.4') }}" id="underscore-js"></script>
<script id="wp-util-js-extra">
    var _wpUtilSettings = {
        ajax: {
            url: '\/wp-admin\/admin-ajax.php'
        }
    }
</script>
<script src="{{ asset('wp-includes/js/wp-util.minadc6.js?ver=6.5.5') }}" id="wp-util-js"></script>
<script id="jet-search-js-extra">
    var jetSearchSettings = {
        ajaxurl: 'https:\/\/sekolah.flymotion.my.id\/wp-admin\/admin-ajax.php',
        action: 'jet_ajax_search',
        nonce: 'c3786f48f8',
    }
</script>
<script src="{{ asset('wp-content/plugins/jet-search/assets/js/jet-search202b.js?ver=2.1.15') }}" id="jet-search-js">
</script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery('#btn-back').on('click', function() {
            window.history.go(-1)
            return false
        })
    })
</script>
