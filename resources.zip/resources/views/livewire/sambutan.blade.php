<main id="content" class="site-main post-403 page type-page status-publish hentry">


    <div class="page-content">
        <div data-elementor-type="wp-page" data-elementor-id="403" class="elementor elementor-403">
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-7073175 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="7073175" data-element_type="section"
                data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;_id&quot;:&quot;3001c4c&quot;,&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2674e316"
                        data-id="2674e316" data-element_type="column" style="padding: 5%;margin-bottom:10%">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <section
                                class="elementor-section elementor-inner-section elementor-element elementor-element-6a2959d elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="6a2959d" data-element_type="section"
                                data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;_id&quot;:&quot;bcea410&quot;,&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-19ae9943"
                                        data-id="19ae9943" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-7a8065ae elementor-widget elementor-widget-heading"
                                                data-id="7a8065ae" data-element_type="widget"
                                                data-widget_type="heading.default">
                                                <div class="elementor-widget-container">
                                                    <style>
                                                        /*! elementor - v3.21.0 - 26-05-2024 */
                                                        .elementor-heading-title {
                                                            padding: 0;
                                                            margin: 0;
                                                            line-height: 1
                                                        }

                                                        .elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a {
                                                            color: inherit;
                                                            font-size: inherit;
                                                            line-height: inherit
                                                        }

                                                        .elementor-widget-heading .elementor-heading-title.elementor-size-small {
                                                            font-size: 15px
                                                        }

                                                        .elementor-widget-heading .elementor-heading-title.elementor-size-medium {
                                                            font-size: 19px
                                                        }

                                                        .elementor-widget-heading .elementor-heading-title.elementor-size-large {
                                                            font-size: 29px
                                                        }

                                                        .elementor-widget-heading .elementor-heading-title.elementor-size-xl {
                                                            font-size: 39px
                                                        }

                                                        .elementor-widget-heading .elementor-heading-title.elementor-size-xxl {
                                                            font-size: 59px
                                                        }
                                                    </style>
                                                    <h1 class="elementor-heading-title elementor-size-default">
                                                        {{ $data->kepala_sekolah }}</h1>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-21d0cf0a elementor-drop-cap-yes elementor-drop-cap-view-default elementor-widget elementor-widget-text-editor"
                                                data-id="21d0cf0a" data-element_type="widget"
                                                data-settings="{&quot;drop_cap&quot;:&quot;yes&quot;}"
                                                data-widget_type="text-editor.default">
                                                <div class="elementor-widget-container">
                                                    <style>
                                                        /*! elementor - v3.21.0 - 26-05-2024 */
                                                        .elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap {
                                                            background-color: #69727d;
                                                            color: #fff
                                                        }

                                                        .elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap {
                                                            color: #69727d;
                                                            border: 3px solid;
                                                            background-color: transparent
                                                        }

                                                        .elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap {
                                                            margin-top: 8px
                                                        }

                                                        .elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter {
                                                            width: 1em;
                                                            height: 1em
                                                        }

                                                        .elementor-widget-text-editor .elementor-drop-cap {
                                                            float: left;
                                                            text-align: center;
                                                            line-height: 1;
                                                            font-size: 50px
                                                        }

                                                        .elementor-widget-text-editor .elementor-drop-cap-letter {
                                                            display: inline-block
                                                        }
                                                    </style>
                                                    <p>{!! $data->sambutan !!}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-73bc0e13"
                                        data-id="73bc0e13" data-element_type="column">
                                        <div class="elementor-widget-wrap elementor-element-populated">
                                            <div class="elementor-element elementor-element-4f85af1e elementor-widget elementor-widget-image"
                                                data-id="4f85af1e" data-element_type="widget"
                                                data-widget_type="image.default">
                                                <div class="elementor-widget-container">
                                                    <img fetchpriority="high" decoding="async" width="394"
                                                        height="579" src="{{ $data->avatar }}"
                                                        class="attachment-full size-full wp-image-114" alt=""
                                                        sizes="(max-width: 394px) 100vw, 394px">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-34d350a8 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="34d350a8" data-element_type="section"
                data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;_id&quot;:&quot;0a13b58&quot;,&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-4fc8b080"
                        data-id="4fc8b080" data-element_type="column">
                        <div class="elementor-widget-wrap">
                        </div>
                    </div>
                    <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-2424d2f8"
                        data-id="2424d2f8" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-5428d94b elementor-widget elementor-widget-heading"
                                data-id="5428d94b" data-element_type="widget" data-widget_type="heading.default">
                                <div class="elementor-widget-container">
                                    <h1 class="elementor-heading-title elementor-size-default">Profil Sekolah</h1>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-3b293387 elementor-widget elementor-widget-jet-table"
                                data-id="3b293387" data-element_type="widget" data-widget_type="jet-table.default">
                                <div class="elementor-widget-container">
                                    <div class="elementor-jet-table jet-elements">
                                        <div class="jet-table-wrapper jet-table-responsive-mobile">
                                            <table class="jet-table jet-table--fa5-compat">
                                                <thead class="jet-table__head">
                                                    <tr class="jet-table__head-row">
                                                        <th class="jet-table__cell elementor-repeater-item-400ddd2 jet-table__head-cell"
                                                            scope="col">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">Sekolah</div>
                                                                </div>
                                                            </div>
                                                        </th>
                                                        <th class="jet-table__cell elementor-repeater-item-67f64d9 jet-table__head-cell"
                                                            scope="col">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">:</div>
                                                                </div>
                                                            </div>
                                                        </th>
                                                        <th class="jet-table__cell elementor-repeater-item-70e050a jet-table__head-cell"
                                                            scope="col">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">Sekolah
                                                                        {{ $data->nama_sekolah }}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody class="jet-table__body">
                                                    <tr class="jet-table__body-row elementor-repeater-item-5a0e629">
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-fb91d9a jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">Alamat</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-8528684 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">:</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-c9785b6 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">
                                                                        {{ $data->alamat }}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr class="jet-table__body-row elementor-repeater-item-ccf7d83">
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-9ea5b0e jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">NPSN</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-e660ae0 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">:</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-b9834ca jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">
                                                                        {{ $data->npsn }}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr class="jet-table__body-row elementor-repeater-item-f8ce60f">
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-1a18073 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">Akreditasi</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-5165303 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">:</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-4f6be36 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">
                                                                        {{ $data->akreditasi }}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr class="jet-table__body-row elementor-repeater-item-f2fa4fc">
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-ea715e3 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">No SK Akreditasi
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-92273a0 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">:</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-641c274 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">
                                                                        {{ $data->sk_akreditasi }}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr class="jet-table__body-row elementor-repeater-item-253b593">
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-ae11bd8 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">Status</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-eb0ec6e jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">:</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-f433320 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">
                                                                        {{ $data->status }}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr class="jet-table__body-row elementor-repeater-item-76471c7">
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-2038120 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">Jenjang
                                                                        Pendidikan</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-5ebb84a jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">:</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-7cae90c jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">
                                                                        {{ $data->jenjang }}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr class="jet-table__body-row elementor-repeater-item-5e14e04">
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-da43b26 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">SK Pendirian
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-469f5b8 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">:</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-6da139e jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">
                                                                        {{ $data->sk_pendirian }}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr class="jet-table__body-row elementor-repeater-item-d015fb2">
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-7e8beba jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">Tanggal SK
                                                                        Pendirian</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-71015ce jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">:</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-a9804d4 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">
                                                                        {{ $data->tgl_sk_pendirian }}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr class="jet-table__body-row elementor-repeater-item-a786c55">
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-dfab8bc jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">SK Ijin
                                                                        Operasional</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-59904c4 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">:</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-e946e4d jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">
                                                                        {{ $data->sk_izin_operasional }}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr class="jet-table__body-row elementor-repeater-item-9f78de0">
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-c0e07d2 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">Tgl SK Ijin
                                                                        Operasional</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-d6b5a51 jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">:</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td
                                                            class="jet-table__cell elementor-repeater-item-47b5d2a jet-table__body-cell">
                                                            <div class="jet-table__cell-inner">
                                                                <div class="jet-table__cell-content">
                                                                    <div class="jet-table__cell-text">
                                                                        {{ $data->tgl_sk_izin_operasional }}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-5426aeb2"
                        data-id="5426aeb2" data-element_type="column">
                        <div class="elementor-widget-wrap">
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-77c2c371 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="77c2c371" data-element_type="section"
                data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;_id&quot;:&quot;97254b1&quot;,&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-924bc56"
                        data-id="924bc56" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-4fc76655 elementor-widget elementor-widget-heading"
                                data-id="4fc76655" data-element_type="widget" data-widget_type="heading.default">
                                <div class="elementor-widget-container">
                                    <h2 class="elementor-heading-title elementor-size-default">Tenaga Pengajar</h2>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-6ded84fc elementor-widget elementor-widget-jet-listing-grid"
                                data-id="6ded84fc" data-element_type="widget"
                                data-settings="{&quot;columns&quot;:&quot;5&quot;,&quot;columns_tablet&quot;:&quot;4&quot;,&quot;columns_mobile&quot;:&quot;2&quot;}"
                                data-widget_type="jet-listing-grid.default">
                                <div class="elementor-widget-container">
                                    <div class="jet-listing-grid jet-listing">
                                        <div class="jet-listing-grid__items grid-col-desk-5 grid-col-tablet-4 grid-col-mobile-2 jet-listing-grid--644"
                                            data-nav="{&quot;enabled&quot;:false,&quot;type&quot;:null,&quot;more_el&quot;:null,&quot;query&quot;:[],&quot;widget_settings&quot;:{&quot;lisitng_id&quot;:644,&quot;posts_num&quot;:5,&quot;columns&quot;:5,&quot;columns_tablet&quot;:4,&quot;columns_mobile&quot;:2,&quot;is_archive_template&quot;:&quot;&quot;,&quot;post_status&quot;:[&quot;publish&quot;],&quot;use_random_posts_num&quot;:&quot;&quot;,&quot;max_posts_num&quot;:9,&quot;not_found_message&quot;:&quot;No data was found&quot;,&quot;is_masonry&quot;:false,&quot;equal_columns_height&quot;:&quot;&quot;,&quot;use_load_more&quot;:&quot;&quot;,&quot;load_more_id&quot;:&quot;&quot;,&quot;load_more_type&quot;:&quot;click&quot;,&quot;use_custom_post_types&quot;:&quot;&quot;,&quot;custom_post_types&quot;:[],&quot;hide_widget_if&quot;:&quot;&quot;,&quot;carousel_enabled&quot;:&quot;&quot;,&quot;slides_to_scroll&quot;:&quot;1&quot;,&quot;arrows&quot;:&quot;true&quot;,&quot;arrow_icon&quot;:&quot;fa fa-angle-left&quot;,&quot;dots&quot;:&quot;&quot;,&quot;autoplay&quot;:&quot;true&quot;,&quot;autoplay_speed&quot;:5000,&quot;infinite&quot;:&quot;true&quot;,&quot;center_mode&quot;:&quot;&quot;,&quot;effect&quot;:&quot;slide&quot;,&quot;speed&quot;:500,&quot;inject_alternative_items&quot;:&quot;&quot;,&quot;injection_items&quot;:[],&quot;scroll_slider_enabled&quot;:&quot;&quot;,&quot;scroll_slider_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;custom_query&quot;:false,&quot;custom_query_id&quot;:&quot;&quot;,&quot;_element_id&quot;:&quot;&quot;}}"
                                            data-page="1" data-pages="1" data-listing-source="posts">

                                            @foreach ($guru as $item)
                                                <div class="jet-listing-grid__item jet-listing-dynamic-post-1117"
                                                    data-post-id="1117">
                                                    <style type="text/css">
                                                        .jet-listing-dynamic-post-1117 .elementor-element.elementor-element-60559f3 .elementor-button {
                                                            background-color: #2f9edd;
                                                        }
                                                    </style>
                                                    <div data-elementor-type="jet-listing-items"
                                                        data-elementor-id="644" class="elementor elementor-644">
                                                        <section
                                                            class="elementor-section elementor-top-section elementor-element elementor-element-3d405c3 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                            data-id="3d405c3" data-element_type="section"
                                                            data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;85a91f6&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                                                            <div
                                                                class="elementor-container elementor-column-gap-default">
                                                                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-c33a81e"
                                                                    data-id="c33a81e" data-element_type="column">
                                                                    <div
                                                                        class="elementor-widget-wrap elementor-element-populated">
                                                                        <div class="elementor-element elementor-element-60559f3 elementor-align-left elementor-absolute elementor-widget elementor-widget-button"
                                                                            data-id="60559f3"
                                                                            data-element_type="widget"
                                                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                                                            data-widget_type="button.default">
                                                                            <div class="elementor-widget-container">
                                                                                <div class="elementor-button-wrapper">
                                                                                    <a class="elementor-button elementor-size-xs"
                                                                                        role="button">
                                                                                        <span
                                                                                            class="elementor-button-content-wrapper">
                                                                                            <span
                                                                                                class="elementor-button-icon elementor-align-icon-left">
                                                                                                <i style="color:white"
                                                                                                    aria-hidden="true"
                                                                                                    class="fas fa-user-tie"></i>
                                                                                            </span>
                                                                                            <span
                                                                                                class="elementor-button-text"
                                                                                                style="color:white">{{ $item->jabatan }}</span>
                                                                                        </span>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="elementor-element elementor-element-71033ba elementor-widget elementor-widget-image"
                                                                            data-id="71033ba"
                                                                            data-element_type="widget"
                                                                            data-widget_type="image.default">
                                                                            <div class="elementor-widget-container">
                                                                                <a
                                                                                    href="{{ route('guruDetailComponent', $item->id) }}">
                                                                                    <img decoding="async"
                                                                                        width="300" height="400"
                                                                                        src="{{ $item->avatar }}"
                                                                                        class="attachment-full size-full wp-image-1198"
                                                                                        alt="{{ $item->fullname }}"
                                                                                        sizes="(max-width: 300px) 100vw, 300px">
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                        <div class="elementor-element elementor-element-d0af098 elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                            data-id="d0af098"
                                                                            data-element_type="widget"
                                                                            data-widget_type="jet-listing-dynamic-field.default">
                                                                            <div class="elementor-widget-container">
                                                                                <div
                                                                                    class="jet-listing jet-listing-dynamic-field display-inline">
                                                                                    <div
                                                                                        class="jet-listing-dynamic-field__inline-wrap">
                                                                                        <div
                                                                                            class="jet-listing-dynamic-field__content">
                                                                                            {{ $item->fullname }}</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </section>
                                                    </div>
                                                </div>
                                            @endforeach

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-26800cb2 elementor-align-center elementor-widget elementor-widget-button"
                                data-id="26800cb2" data-element_type="widget" data-widget_type="button.default">
                                <div class="elementor-widget-container">
                                    <div class="elementor-button-wrapper">
                                        <a class="elementor-button elementor-button-link elementor-size-xs"
                                            href="../guru/index.html">
                                            <span class="elementor-button-content-wrapper">
                                                <span class="elementor-button-icon elementor-align-icon-left">
                                                    <i aria-hidden="true" class="fas fa-plus-circle"></i> </span>
                                                <span class="elementor-button-text">Lihat Semuanya</span>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-39ac293b elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                                data-id="39ac293b" data-element_type="widget" data-widget_type="divider.default">
                                <div class="elementor-widget-container">
                                    <style>
                                        /*! elementor - v3.21.0 - 26-05-2024 */
                                        .elementor-widget-divider {
                                            --divider-border-style: none;
                                            --divider-border-width: 1px;
                                            --divider-color: #0c0d0e;
                                            --divider-icon-size: 20px;
                                            --divider-element-spacing: 10px;
                                            --divider-pattern-height: 24px;
                                            --divider-pattern-size: 20px;
                                            --divider-pattern-url: none;
                                            --divider-pattern-repeat: repeat-x
                                        }

                                        .elementor-widget-divider .elementor-divider {
                                            display: flex
                                        }

                                        .elementor-widget-divider .elementor-divider__text {
                                            font-size: 15px;
                                            line-height: 1;
                                            max-width: 95%
                                        }

                                        .elementor-widget-divider .elementor-divider__element {
                                            margin: 0 var(--divider-element-spacing);
                                            flex-shrink: 0
                                        }

                                        .elementor-widget-divider .elementor-icon {
                                            font-size: var(--divider-icon-size)
                                        }

                                        .elementor-widget-divider .elementor-divider-separator {
                                            display: flex;
                                            margin: 0;
                                            direction: ltr
                                        }

                                        .elementor-widget-divider--view-line_icon .elementor-divider-separator,
                                        .elementor-widget-divider--view-line_text .elementor-divider-separator {
                                            align-items: center
                                        }

                                        .elementor-widget-divider--view-line_icon .elementor-divider-separator:after,
                                        .elementor-widget-divider--view-line_icon .elementor-divider-separator:before,
                                        .elementor-widget-divider--view-line_text .elementor-divider-separator:after,
                                        .elementor-widget-divider--view-line_text .elementor-divider-separator:before {
                                            display: block;
                                            content: "";
                                            border-block-end: 0;
                                            flex-grow: 1;
                                            border-block-start: var(--divider-border-width) var(--divider-border-style) var(--divider-color)
                                        }

                                        .elementor-widget-divider--element-align-left .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type {
                                            flex-grow: 0;
                                            flex-shrink: 100
                                        }

                                        .elementor-widget-divider--element-align-left .elementor-divider-separator:before {
                                            content: none
                                        }

                                        .elementor-widget-divider--element-align-left .elementor-divider__element {
                                            margin-left: 0
                                        }

                                        .elementor-widget-divider--element-align-right .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type {
                                            flex-grow: 0;
                                            flex-shrink: 100
                                        }

                                        .elementor-widget-divider--element-align-right .elementor-divider-separator:after {
                                            content: none
                                        }

                                        .elementor-widget-divider--element-align-right .elementor-divider__element {
                                            margin-right: 0
                                        }

                                        .elementor-widget-divider--element-align-start .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type {
                                            flex-grow: 0;
                                            flex-shrink: 100
                                        }

                                        .elementor-widget-divider--element-align-start .elementor-divider-separator:before {
                                            content: none
                                        }

                                        .elementor-widget-divider--element-align-start .elementor-divider__element {
                                            margin-inline-start: 0
                                        }

                                        .elementor-widget-divider--element-align-end .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type {
                                            flex-grow: 0;
                                            flex-shrink: 100
                                        }

                                        .elementor-widget-divider--element-align-end .elementor-divider-separator:after {
                                            content: none
                                        }

                                        .elementor-widget-divider--element-align-end .elementor-divider__element {
                                            margin-inline-end: 0
                                        }

                                        .elementor-widget-divider:not(.elementor-widget-divider--view-line_text):not(.elementor-widget-divider--view-line_icon) .elementor-divider-separator {
                                            border-block-start: var(--divider-border-width) var(--divider-border-style) var(--divider-color)
                                        }

                                        .elementor-widget-divider--separator-type-pattern {
                                            --divider-border-style: none
                                        }

                                        .elementor-widget-divider--separator-type-pattern.elementor-widget-divider--view-line .elementor-divider-separator,
                                        .elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:after,
                                        .elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:before,
                                        .elementor-widget-divider--separator-type-pattern:not([class*=elementor-widget-divider--view]) .elementor-divider-separator {
                                            width: 100%;
                                            min-height: var(--divider-pattern-height);
                                            -webkit-mask-size: var(--divider-pattern-size) 100%;
                                            mask-size: var(--divider-pattern-size) 100%;
                                            -webkit-mask-repeat: var(--divider-pattern-repeat);
                                            mask-repeat: var(--divider-pattern-repeat);
                                            background-color: var(--divider-color);
                                            -webkit-mask-image: var(--divider-pattern-url);
                                            mask-image: var(--divider-pattern-url)
                                        }

                                        .elementor-widget-divider--no-spacing {
                                            --divider-pattern-size: auto
                                        }

                                        .elementor-widget-divider--bg-round {
                                            --divider-pattern-repeat: round
                                        }

                                        .rtl .elementor-widget-divider .elementor-divider__text {
                                            direction: rtl
                                        }

                                        .e-con-inner>.elementor-widget-divider,
                                        .e-con>.elementor-widget-divider {
                                            width: var(--container-widget-width, 100%);
                                            --flex-grow: var(--container-widget-flex-grow)
                                        }
                                    </style>
                                    <div class="elementor-divider">
                                        <span class="elementor-divider-separator">
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <div class="post-tags">
        </div>
    </div>


</main>
