<section
    class="elementor-section elementor-top-section elementor-element elementor-element-44e48cdb elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="44e48cdb" data-element_type="section"
    data-settings='{"background_background":"classic","jet_parallax_layout_list":[{"_id":"998e88b","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-58d50d2d"
            data-id="58d50d2d" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <section
                    class="elementor-section elementor-inner-section elementor-element elementor-element-64cecd30 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="64cecd30" data-element_type="section"
                    data-settings='{"jet_parallax_layout_list":[{"_id":"ff9d372","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5c919925"
                            data-id="5c919925" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-4d27eef4 elementor-widget elementor-widget-heading"
                                    data-id="4d27eef4" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Agenda
                                        </h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-a1e37e5 elementor-widget elementor-widget-heading"
                                    data-id="a1e37e5" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Agenda Sekolah {{ $sekolah->nama_sekolah }}
                                        </h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-2f7b908e"
                            data-id="2f7b908e" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-6744e3e6 elementor-view-default elementor-widget elementor-widget-icon"
                                    data-id="6744e3e6" data-element_type="widget" data-widget_type="icon.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-icon-wrapper">
                                            <a class="elementor-icon" href="{{ route('agendaComponent') }}">
                                                <i aria-hidden="true" class="fas fa-chevron-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <div class="elementor-element elementor-element-49b461d0 elementor-widget elementor-widget-jet-listing-grid"
                    data-id="49b461d0" data-element_type="widget" data-settings='{"columns":3}'
                    data-widget_type="jet-listing-grid.default">
                    <div class="elementor-widget-container">
                        <div class="jet-listing-grid jet-listing">
                            <div
                                class="jet-listing-grid__scroll-slider jet-listing-grid__scroll-slider-tablet jet-listing-grid__scroll-slider-mobile">
                                <div class="jet-listing-grid__items grid-col-desk-3 grid-col-tablet-3 grid-col-mobile-3 jet-listing-grid--12"
                                    data-nav='{"enabled":false,"type":null,"more_el":null,"query":[],"widget_settings":{"lisitng_id":12,"posts_num":3,"columns":3,"columns_tablet":3,"columns_mobile":3,"is_archive_template":"","post_status":["publish"],"use_random_posts_num":"","max_posts_num":9,"not_found_message":"Tidak ada agenda","is_masonry":false,"equal_columns_height":"","use_load_more":"","load_more_id":"","load_more_type":"click","use_custom_post_types":"","custom_post_types":[],"hide_widget_if":"","carousel_enabled":"","slides_to_scroll":"1","arrows":"true","arrow_icon":"fa fa-angle-left","dots":"","autoplay":"true","autoplay_speed":5000,"infinite":"true","center_mode":"","effect":"slide","speed":500,"inject_alternative_items":"","injection_items":[],"scroll_slider_enabled":"yes","scroll_slider_on":["tablet","mobile"],"custom_query":false,"custom_query_id":"","_element_id":""}}'
                                    data-page="1" data-pages="2" data-listing-source="posts">
                                    @foreach ($agenda as $item)
                                        <div class="jet-listing-grid__item jet-listing-dynamic-post-1593"
                                            data-post-id="1593">
                                            <style type="text/css">
                                                .jet-listing-dynamic-post-1593 .elementor-element.elementor-element-dede923 .jet-listing-dynamic-field.display-multiline,
                                                .jet-listing-dynamic-post-1593 .elementor-element.elementor-element-dede923 .jet-listing-dynamic-field.display-inline .jet-listing-dynamic-field__inline-wrap {
                                                    background-color: #ffa800;
                                                }

                                                .jet-listing-dynamic-post-1593 .elementor-element.elementor-element-9a20751 .elementor-icon-list-icon i {
                                                    color: #ffa800;
                                                }

                                                .jet-listing-dynamic-post-1593 .elementor-element.elementor-element-9a20751 .elementor-icon-list-icon svg {
                                                    fill: #ffa800;
                                                }

                                                .jet-listing-dynamic-post-1593 .elementor-element.elementor-element-e6909dd .jet-countdown-timer__item-value {
                                                    color: #03626f;
                                                }
                                            </style>
                                            <div data-elementor-type="jet-listing-items" data-elementor-id="12"
                                                class="elementor elementor-12">
                                                <section
                                                    class="elementor-section elementor-top-section elementor-element elementor-element-f38fed9 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                    data-id="f38fed9" data-element_type="section"
                                                    data-settings='{"jet_parallax_layout_list":[{"jet_parallax_layout_image":{"url":"","id":"","size":""},"_id":"646e780","jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}],"background_background":"classic"}'>
                                                    <div class="elementor-container elementor-column-gap-default">
                                                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-690727c"
                                                            data-id="690727c" data-element_type="column"
                                                            data-settings='{"background_background":"classic"}'>
                                                            <div
                                                                class="elementor-widget-wrap elementor-element-populated">
                                                                <div class="elementor-element elementor-element-dede923 elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                    data-id="dede923" data-element_type="widget"
                                                                    data-settings='{"_position":"absolute"}'
                                                                    data-widget_type="jet-listing-dynamic-field.default">
                                                                    <div class="elementor-widget-container">
                                                                        <div
                                                                            class="jet-listing jet-listing-dynamic-field display-inline">
                                                                            <div
                                                                                class="jet-listing-dynamic-field__inline-wrap">
                                                                                <i class="jet-listing-dynamic-field__icon far fa-calendar-alt"
                                                                                    aria-hidden="true"></i>
                                                                                <div
                                                                                    class="jet-listing-dynamic-field__content">
                                                                                    {{ $item->pelaksanaan }}
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-99cf020 elementor-widget elementor-widget-image"
                                                                    data-id="99cf020" data-element_type="widget"
                                                                    data-widget_type="image.default">
                                                                    <div class="elementor-widget-container">
                                                                        <a
                                                                            href="{{ route('agendaDetailComponent', $item->slug) }}">
                                                                            <img width="450" height="426"
                                                                                src="{{ $item->thumbnail }}"
                                                                                title="{{ $item->judul }}"
                                                                                alt="{{ $item->judul }}" />
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-b123191 elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                    data-id="b123191" data-element_type="widget"
                                                                    data-widget_type="jet-listing-dynamic-field.default">
                                                                    <div class="elementor-widget-container">
                                                                        <div
                                                                            class="jet-listing jet-listing-dynamic-field display-inline">
                                                                            <div
                                                                                class="jet-listing-dynamic-field__inline-wrap">
                                                                                <div
                                                                                    class="jet-listing-dynamic-field__content">
                                                                                    {{ $item->judul }}
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-9a20751 elementor-icon-list--layout-inline elementor-align-left elementor-tablet-align-left elementor-mobile-align-left elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                                                    data-id="9a20751" data-element_type="widget"
                                                                    data-widget_type="icon-list.default">
                                                                    <div class="elementor-widget-container">
                                                                        <ul
                                                                            class="elementor-icon-list-items elementor-inline-items">
                                                                            <li
                                                                                class="elementor-icon-list-item elementor-inline-item">
                                                                                <span class="elementor-icon-list-icon">
                                                                                    <i aria-hidden="true"
                                                                                        class="fas fa-map-pin"></i>
                                                                                </span>
                                                                                <span class="elementor-icon-list-text">
                                                                                    {{ $item->lokasi }}</span>
                                                                            </li>
                                                                            <li
                                                                                class="elementor-icon-list-item elementor-inline-item">
                                                                                <span class="elementor-icon-list-icon">
                                                                                    <i aria-hidden="true"
                                                                                        class="far fa-clock"></i>
                                                                                </span>
                                                                                <span class="elementor-icon-list-text">
                                                                                    {{ $item->start }} -
                                                                                    {{ $item->end }}</span>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </section>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
