<section
    class="elementor-section elementor-top-section elementor-element elementor-element-22e8993a elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="22e8993a" data-element_type="section"
    data-settings='{"background_background":"classic","jet_parallax_layout_list":[{"_id":"998e88b","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-193e1520"
            data-id="193e1520" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <section
                    class="elementor-section elementor-inner-section elementor-element elementor-element-4c0e73d4 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="4c0e73d4" data-element_type="section"
                    data-settings='{"jet_parallax_layout_list":[{"_id":"ff9d372","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-76d703b7"
                            data-id="76d703b7" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-4f167459 elementor-widget elementor-widget-heading"
                                    data-id="4f167459" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Daftar Guru & Staf
                                        </h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-579bc3f5 elementor-widget elementor-widget-heading"
                                    data-id="579bc3f5" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Daftar Guru Sekolah {{ $sekolah->nama_sekolah }}
                                        </h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-3d565d3b"
                            data-id="3d565d3b" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-6d0dbb35 elementor-view-default elementor-widget elementor-widget-icon"
                                    data-id="6d0dbb35" data-element_type="widget" data-widget_type="icon.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-icon-wrapper">
                                            <a class="elementor-icon" href="{{ route('guruComponent') }}"
                                                wire:navigate.hover>
                                                <i aria-hidden="true" class="fas fa-chevron-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <div class="elementor-element elementor-element-3fb0c1ad elementor-widget elementor-widget-jet-listing-grid"
                    data-id="3fb0c1ad" data-element_type="widget" data-settings='{"columns":"5"}'
                    data-widget_type="jet-listing-grid.default">
                    <div class="elementor-widget-container">
                        <div class="jet-listing-grid jet-listing">
                            <div
                                class="jet-listing-grid__scroll-slider jet-listing-grid__scroll-slider-tablet jet-listing-grid__scroll-slider-mobile">
                                <div class="jet-listing-grid__items grid-col-desk-5 grid-col-tablet-5 grid-col-mobile-5 jet-listing-grid--20"
                                    data-nav='{"enabled":false,"type":null,"more_el":null,"query":[],"widget_settings":{"lisitng_id":20,"posts_num":5,"columns":5,"columns_tablet":5,"columns_mobile":5,"is_archive_template":"","post_status":["publish"],"use_random_posts_num":"","max_posts_num":9,"not_found_message":"Tidak ada guru","is_masonry":false,"equal_columns_height":"","use_load_more":"","load_more_id":"","load_more_type":"click","use_custom_post_types":"","custom_post_types":[],"hide_widget_if":"","carousel_enabled":"","slides_to_scroll":"1","arrows":"true","arrow_icon":"fa fa-angle-left","dots":"","autoplay":"true","autoplay_speed":5000,"infinite":"true","center_mode":"","effect":"slide","speed":500,"inject_alternative_items":"","injection_items":[],"scroll_slider_enabled":"yes","scroll_slider_on":["tablet","mobile"],"custom_query":false,"custom_query_id":"","_element_id":""}}'
                                    data-page="1" data-pages="1" data-listing-source="posts">
                                    @foreach ($guru as $item)
                                        <div class="jet-listing-grid__item jet-listing-dynamic-post-112"
                                            data-post-id="112">
                                            <style type="text/css">
                                                .jet-listing-dynamic-post-112 .elementor-element.elementor-element-9c68f04 .elementor-button {
                                                    background-color: #03626f;
                                                }
                                            </style>
                                            <div data-elementor-type="jet-listing-items" data-elementor-id="20"
                                                class="elementor elementor-20">
                                                <section
                                                    class="elementor-section elementor-top-section elementor-element elementor-element-9251ac5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                    data-id="9251ac5" data-element_type="section"
                                                    data-settings='{"jet_parallax_layout_list":[{"jet_parallax_layout_image":{"url":"","id":"","size":""},"_id":"85a91f6","jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                                                    <div class="elementor-container elementor-column-gap-default">
                                                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5a5f149"
                                                            data-id="5a5f149" data-element_type="column">
                                                            <div
                                                                class="elementor-widget-wrap elementor-element-populated">
                                                                <div class="elementor-element elementor-element-9c68f04 elementor-align-left elementor-absolute elementor-widget elementor-widget-button"
                                                                    data-id="9c68f04" data-element_type="widget"
                                                                    data-settings='{"_position":"absolute"}'
                                                                    data-widget_type="button.default">
                                                                    <div class="elementor-widget-container">
                                                                        <div class="elementor-button-wrapper">
                                                                            <a class="elementor-button elementor-size-xs"
                                                                                role="button">
                                                                                <span
                                                                                    class="elementor-button-content-wrapper">
                                                                                    <span
                                                                                        class="elementor-button-icon elementor-align-icon-left">
                                                                                        <i aria-hidden="true"
                                                                                            class="fas fa-user-tie"></i>
                                                                                    </span>
                                                                                    <span
                                                                                        class="elementor-button-text">{{ $item->jabatan }}</span>
                                                                                </span>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-a7bb433 elementor-widget elementor-widget-image"
                                                                    data-id="a7bb433" data-element_type="widget"
                                                                    data-widget_type="image.default">
                                                                    <div class="elementor-widget-container">
                                                                        <a href="guru/ramadian-t-laksana/index.html">
                                                                            <img loading="lazy" decoding="async"
                                                                                width="394" height="579"
                                                                                src="{{ $item->avatar }}"
                                                                                class="attachment-full size-full wp-image-114"
                                                                                alt="{{ $item->fullname }}"
                                                                                srcset="{{ $item->fullname }}"
                                                                                sizes="(max-width: 394px) 100vw, 394px" />
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-1615d8e elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                    data-id="1615d8e" data-element_type="widget"
                                                                    data-widget_type="jet-listing-dynamic-field.default">
                                                                    <div class="elementor-widget-container">
                                                                        <div
                                                                            class="jet-listing jet-listing-dynamic-field display-inline">
                                                                            <div
                                                                                class="jet-listing-dynamic-field__inline-wrap">
                                                                                <div
                                                                                    class="jet-listing-dynamic-field__content">
                                                                                    {{ $item->fullname }}
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section>
                                            </div>
                                        </div>
                                    @endforeach
                                    {{-- <div class="jet-listing-grid__item jet-listing-dynamic-post-1116"
                                        data-post-id="1116">
                                        <style type="text/css">
                                            .jet-listing-dynamic-post-1116 .elementor-element.elementor-element-9c68f04 .elementor-button {
                                                background-color: #03626f;
                                            }
                                        </style>
                                        <div data-elementor-type="jet-listing-items" data-elementor-id="20"
                                            class="elementor elementor-20">
                                            <section
                                                class="elementor-section elementor-top-section elementor-element elementor-element-9251ac5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                data-id="9251ac5" data-element_type="section"
                                                data-settings='{"jet_parallax_layout_list":[{"jet_parallax_layout_image":{"url":"","id":"","size":""},"_id":"85a91f6","jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                                                <div class="elementor-container elementor-column-gap-default">
                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5a5f149"
                                                        data-id="5a5f149" data-element_type="column">
                                                        <div class="elementor-widget-wrap elementor-element-populated">
                                                            <div class="elementor-element elementor-element-9c68f04 elementor-align-left elementor-absolute elementor-widget elementor-widget-button"
                                                                data-id="9c68f04" data-element_type="widget"
                                                                data-settings='{"_position":"absolute"}'
                                                                data-widget_type="button.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="elementor-button-wrapper">
                                                                        <a class="elementor-button elementor-size-xs"
                                                                            role="button">
                                                                            <span
                                                                                class="elementor-button-content-wrapper">
                                                                                <span
                                                                                    class="elementor-button-icon elementor-align-icon-left">
                                                                                    <i aria-hidden="true"
                                                                                        class="fas fa-user-tie"></i>
                                                                                </span>
                                                                                <span
                                                                                    class="elementor-button-text">Guru
                                                                                    BK</span>
                                                                            </span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-a7bb433 elementor-widget elementor-widget-image"
                                                                data-id="a7bb433" data-element_type="widget"
                                                                data-widget_type="image.default">
                                                                <div class="elementor-widget-container">
                                                                    <a href="guru/selena/index.html">
                                                                        <img loading="lazy" decoding="async"
                                                                            width="300" height="400"
                                                                            src="wp-content/uploads/2022/04/bhs.png"
                                                                            class="attachment-full size-full wp-image-1197"
                                                                            alt=""
                                                                            srcset="
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/bhs.png         300w,
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/bhs-225x300.png 225w
                                                "
                                                                            sizes="(max-width: 300px) 100vw, 300px" />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-1615d8e elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                data-id="1615d8e" data-element_type="widget"
                                                                data-widget_type="jet-listing-dynamic-field.default">
                                                                <div class="elementor-widget-container">
                                                                    <div
                                                                        class="jet-listing jet-listing-dynamic-field display-inline">
                                                                        <div
                                                                            class="jet-listing-dynamic-field__inline-wrap">
                                                                            <div
                                                                                class="jet-listing-dynamic-field__content">
                                                                                Selena Gemes
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-1117"
                                        data-post-id="1117">
                                        <style type="text/css">
                                            .jet-listing-dynamic-post-1117 .elementor-element.elementor-element-9c68f04 .elementor-button {
                                                background-color: #03626f;
                                            }
                                        </style>
                                        <div data-elementor-type="jet-listing-items" data-elementor-id="20"
                                            class="elementor elementor-20">
                                            <section
                                                class="elementor-section elementor-top-section elementor-element elementor-element-9251ac5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                data-id="9251ac5" data-element_type="section"
                                                data-settings='{"jet_parallax_layout_list":[{"jet_parallax_layout_image":{"url":"","id":"","size":""},"_id":"85a91f6","jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                                                <div class="elementor-container elementor-column-gap-default">
                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5a5f149"
                                                        data-id="5a5f149" data-element_type="column">
                                                        <div class="elementor-widget-wrap elementor-element-populated">
                                                            <div class="elementor-element elementor-element-9c68f04 elementor-align-left elementor-absolute elementor-widget elementor-widget-button"
                                                                data-id="9c68f04" data-element_type="widget"
                                                                data-settings='{"_position":"absolute"}'
                                                                data-widget_type="button.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="elementor-button-wrapper">
                                                                        <a class="elementor-button elementor-size-xs"
                                                                            role="button">
                                                                            <span
                                                                                class="elementor-button-content-wrapper">
                                                                                <span
                                                                                    class="elementor-button-icon elementor-align-icon-left">
                                                                                    <i aria-hidden="true"
                                                                                        class="fas fa-user-tie"></i>
                                                                                </span>
                                                                                <span
                                                                                    class="elementor-button-text">Guru
                                                                                    Kelas</span>
                                                                            </span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-a7bb433 elementor-widget elementor-widget-image"
                                                                data-id="a7bb433" data-element_type="widget"
                                                                data-widget_type="image.default">
                                                                <div class="elementor-widget-container">
                                                                    <a href="guru/agnes-udanica/index.html">
                                                                        <img loading="lazy" decoding="async"
                                                                            width="300" height="400"
                                                                            src="wp-content/uploads/2022/04/kimia.png"
                                                                            class="attachment-full size-full wp-image-1198"
                                                                            alt=""
                                                                            srcset="
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/kimia.png         300w,
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/kimia-225x300.png 225w
                                                "
                                                                            sizes="(max-width: 300px) 100vw, 300px" />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-1615d8e elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                data-id="1615d8e" data-element_type="widget"
                                                                data-widget_type="jet-listing-dynamic-field.default">
                                                                <div class="elementor-widget-container">
                                                                    <div
                                                                        class="jet-listing jet-listing-dynamic-field display-inline">
                                                                        <div
                                                                            class="jet-listing-dynamic-field__inline-wrap">
                                                                            <div
                                                                                class="jet-listing-dynamic-field__content">
                                                                                Agnes Udanica
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
