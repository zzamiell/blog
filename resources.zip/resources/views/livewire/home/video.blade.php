<section
    class="elementor-section elementor-top-section elementor-element elementor-element-258670e elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="258670e" data-element_type="section"
    data-settings='{"background_background":"classic","jet_parallax_layout_list":[{"_id":"998e88b","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ecf2eec"
            data-id="ecf2eec" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <section
                    class="elementor-section elementor-inner-section elementor-element elementor-element-02061f9 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="02061f9" data-element_type="section"
                    data-settings='{"jet_parallax_layout_list":[{"_id":"ff9d372","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-54336b7"
                            data-id="54336b7" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-bf2841d elementor-widget elementor-widget-heading"
                                    data-id="bf2841d" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Galeri Video
                                        </h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-7cbe652 elementor-widget elementor-widget-heading"
                                    data-id="7cbe652" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Galeri Video Sekolah {{ $sekolah->nama_sekolah }}
                                        </h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-204067c"
                            data-id="204067c" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-f15d9f5 elementor-view-default elementor-widget elementor-widget-icon"
                                    data-id="f15d9f5" data-element_type="widget" data-widget_type="icon.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-icon-wrapper">
                                            <a class="elementor-icon" href="galeri-video/index.html">
                                                <i aria-hidden="true" class="fas fa-chevron-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <div class="elementor-element elementor-element-6822b97 elementor-widget elementor-widget-jet-listing-grid"
                    data-id="6822b97" data-element_type="widget"
                    data-settings='{"columns":"3","columns_tablet":"3","columns_mobile":"2"}'
                    data-widget_type="jet-listing-grid.default">
                    <div class="elementor-widget-container">
                        <div class="jet-listing-grid jet-listing">
                            <div class="jet-listing-grid__items grid-col-desk-3 grid-col-tablet-3 grid-col-mobile-2 jet-listing-grid--1310"
                                data-nav='{"enabled":false,"type":null,"more_el":null,"query":[],"widget_settings":{"lisitng_id":1310,"posts_num":6,"columns":3,"columns_tablet":3,"columns_mobile":2,"is_archive_template":"","post_status":["publish"],"use_random_posts_num":"","max_posts_num":9,"not_found_message":"Tidak ada fasilitas","is_masonry":false,"equal_columns_height":"","use_load_more":"","load_more_id":"","load_more_type":"click","use_custom_post_types":"","custom_post_types":[],"hide_widget_if":"","carousel_enabled":"","slides_to_scroll":"1","arrows":"true","arrow_icon":"fa fa-angle-left","dots":"","autoplay":"true","autoplay_speed":5000,"infinite":"true","center_mode":"","effect":"slide","speed":500,"inject_alternative_items":"","injection_items":[],"scroll_slider_enabled":"","scroll_slider_on":["desktop","tablet","mobile"],"custom_query":false,"custom_query_id":"","_element_id":""}}'
                                data-page="1" data-pages="1" data-listing-source="posts">
                                <div class="jet-listing-grid__item jet-listing-dynamic-post-1596" data-post-id="1596">
                                    <div data-elementor-type="jet-listing-items" data-elementor-id="1310"
                                        class="elementor elementor-1310">
                                        <section
                                            class="elementor-section elementor-top-section elementor-element elementor-element-a261890 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                            data-id="a261890" data-element_type="section"
                                            data-settings='{"jet_parallax_layout_list":[]}'>
                                            <div class="elementor-container elementor-column-gap-default">
                                                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-784e68e"
                                                    data-id="784e68e" data-element_type="column">
                                                    <div class="elementor-widget-wrap elementor-element-populated">
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                                <div class="jet-listing-grid__item jet-listing-dynamic-post-1453" data-post-id="1453">
                                    <div data-elementor-type="jet-listing-items" data-elementor-id="1310"
                                        class="elementor elementor-1310">
                                        <section
                                            class="elementor-section elementor-top-section elementor-element elementor-element-a261890 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                            data-id="a261890" data-element_type="section"
                                            data-settings='{"jet_parallax_layout_list":[]}'>
                                            <div class="elementor-container elementor-column-gap-default">
                                                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-784e68e"
                                                    data-id="784e68e" data-element_type="column">
                                                    <div class="elementor-widget-wrap elementor-element-populated">
                                                        <div class="elementor-element elementor-element-4088c58 elementor-widget elementor-widget-video"
                                                            data-id="4088c58" data-element_type="widget"
                                                            data-settings='{"youtube_url":"https:\/\/youtu.be\/6y3xj_n8Fak","lazy_load":"yes","video_type":"youtube","controls":"yes"}'
                                                            data-widget_type="video.default">
                                                            <div class="elementor-widget-container">
                                                                <style>
                                                                    /*! elementor - v3.21.0 - 26-05-2024 */
                                                                    .elementor-widget-video .elementor-widget-container {
                                                                        overflow: hidden;
                                                                        transform: translateZ(0);
                                                                    }

                                                                    .elementor-widget-video .elementor-wrapper {
                                                                        aspect-ratio: var(--video-aspect-ratio);
                                                                    }

                                                                    .elementor-widget-video .elementor-wrapper iframe,
                                                                    .elementor-widget-video .elementor-wrapper video {
                                                                        height: 100%;
                                                                        width: 100%;
                                                                        display: flex;
                                                                        border: none;
                                                                        background-color: #000;
                                                                    }

                                                                    @supports not (aspect-ratio: 1/1) {
                                                                        .elementor-widget-video .elementor-wrapper {
                                                                            position: relative;
                                                                            overflow: hidden;
                                                                            height: 0;
                                                                            padding-bottom: calc(100% / var(--video-aspect-ratio));
                                                                        }

                                                                        .elementor-widget-video .elementor-wrapper iframe,
                                                                        .elementor-widget-video .elementor-wrapper video {
                                                                            position: absolute;
                                                                            top: 0;
                                                                            right: 0;
                                                                            bottom: 0;
                                                                            left: 0;
                                                                        }
                                                                    }

                                                                    .elementor-widget-video .elementor-open-inline .elementor-custom-embed-image-overlay {
                                                                        position: absolute;
                                                                        top: 0;
                                                                        right: 0;
                                                                        bottom: 0;
                                                                        left: 0;
                                                                        background-size: cover;
                                                                        background-position: 50%;
                                                                    }

                                                                    .elementor-widget-video .elementor-custom-embed-image-overlay {
                                                                        cursor: pointer;
                                                                        text-align: center;
                                                                    }

                                                                    .elementor-widget-video .elementor-custom-embed-image-overlay:hover .elementor-custom-embed-play i {
                                                                        opacity: 1;
                                                                    }

                                                                    .elementor-widget-video .elementor-custom-embed-image-overlay img {
                                                                        display: block;
                                                                        width: 100%;
                                                                        aspect-ratio: var(--video-aspect-ratio);
                                                                        -o-object-fit: cover;
                                                                        object-fit: cover;
                                                                        -o-object-position: center center;
                                                                        object-position: center center;
                                                                    }

                                                                    @supports not (aspect-ratio: 1/1) {
                                                                        .elementor-widget-video .elementor-custom-embed-image-overlay {
                                                                            position: relative;
                                                                            overflow: hidden;
                                                                            height: 0;
                                                                            padding-bottom: calc(100% / var(--video-aspect-ratio));
                                                                        }

                                                                        .elementor-widget-video .elementor-custom-embed-image-overlay img {
                                                                            position: absolute;
                                                                            top: 0;
                                                                            right: 0;
                                                                            bottom: 0;
                                                                            left: 0;
                                                                        }
                                                                    }

                                                                    .elementor-widget-video .e-hosted-video .elementor-video {
                                                                        -o-object-fit: cover;
                                                                        object-fit: cover;
                                                                    }

                                                                    .e-con-inner>.elementor-widget-video,
                                                                    .e-con>.elementor-widget-video {
                                                                        width: var(--container-widget-width);
                                                                        --flex-grow: var(--container-widget-flex-grow);
                                                                    }
                                                                </style>
                                                                <div class="elementor-wrapper elementor-open-inline">
                                                                    <div class="elementor-video"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                                <div class="jet-listing-grid__item jet-listing-dynamic-post-1315" data-post-id="1315">
                                    <div data-elementor-type="jet-listing-items" data-elementor-id="1310"
                                        class="elementor elementor-1310">
                                        <section
                                            class="elementor-section elementor-top-section elementor-element elementor-element-a261890 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                            data-id="a261890" data-element_type="section"
                                            data-settings='{"jet_parallax_layout_list":[]}'>
                                            <div class="elementor-container elementor-column-gap-default">
                                                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-784e68e"
                                                    data-id="784e68e" data-element_type="column">
                                                    <div class="elementor-widget-wrap elementor-element-populated">
                                                        <div class="elementor-element elementor-element-4088c58 elementor-widget elementor-widget-video"
                                                            data-id="4088c58" data-element_type="widget"
                                                            data-settings='{"youtube_url":"https:\/\/www.youtube.com\/watch?v=M8ndJG8nZKM","lazy_load":"yes","video_type":"youtube","controls":"yes"}'
                                                            data-widget_type="video.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="elementor-wrapper elementor-open-inline">
                                                                    <div class="elementor-video"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                                <div class="jet-listing-grid__item jet-listing-dynamic-post-1314" data-post-id="1314">
                                    <div data-elementor-type="jet-listing-items" data-elementor-id="1310"
                                        class="elementor elementor-1310">
                                        <section
                                            class="elementor-section elementor-top-section elementor-element elementor-element-a261890 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                            data-id="a261890" data-element_type="section"
                                            data-settings='{"jet_parallax_layout_list":[]}'>
                                            <div class="elementor-container elementor-column-gap-default">
                                                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-784e68e"
                                                    data-id="784e68e" data-element_type="column">
                                                    <div class="elementor-widget-wrap elementor-element-populated">
                                                        <div class="elementor-element elementor-element-4088c58 elementor-widget elementor-widget-video"
                                                            data-id="4088c58" data-element_type="widget"
                                                            data-settings='{"youtube_url":"https:\/\/www.youtube.com\/watch?v=YvkfWHjAjZE","lazy_load":"yes","video_type":"youtube","controls":"yes"}'
                                                            data-widget_type="video.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="elementor-wrapper elementor-open-inline">
                                                                    <div class="elementor-video"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                                <div class="jet-listing-grid__item jet-listing-dynamic-post-1309" data-post-id="1309">
                                    <div data-elementor-type="jet-listing-items" data-elementor-id="1310"
                                        class="elementor elementor-1310">
                                        <section
                                            class="elementor-section elementor-top-section elementor-element elementor-element-a261890 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                            data-id="a261890" data-element_type="section"
                                            data-settings='{"jet_parallax_layout_list":[]}'>
                                            <div class="elementor-container elementor-column-gap-default">
                                                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-784e68e"
                                                    data-id="784e68e" data-element_type="column">
                                                    <div class="elementor-widget-wrap elementor-element-populated">
                                                        <div class="elementor-element elementor-element-4088c58 elementor-widget elementor-widget-video"
                                                            data-id="4088c58" data-element_type="widget"
                                                            data-settings='{"youtube_url":"https:\/\/www.youtube.com\/watch?v=FwfOTi5J1T4","lazy_load":"yes","video_type":"youtube","controls":"yes"}'
                                                            data-widget_type="video.default">
                                                            <div class="elementor-widget-container">
                                                                <div class="elementor-wrapper elementor-open-inline">
                                                                    <div class="elementor-video"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
