<section
    class="elementor-section elementor-top-section elementor-element elementor-element-1a22f897 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="1a22f897" data-element_type="section"
    data-settings='{"jet_parallax_layout_list":[{"_id":"7962ecc","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}],"background_background":"classic"}'>
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1e222d74"
            data-id="1e222d74" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-5bdb7e49 elementor-widget elementor-widget-heading"
                    data-id="5bdb7e49" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <style>
                            /*! elementor - v3.21.0 - 26-05-2024 */
                            .elementor-heading-title {
                                padding: 0;
                                margin: 0;
                                line-height: 1;
                            }

                            .elementor-widget-heading .elementor-heading-title[class*='elementor-size-']>a {
                                color: inherit;
                                font-size: inherit;
                                line-height: inherit;
                            }

                            .elementor-widget-heading .elementor-heading-title.elementor-size-small {
                                font-size: 15px;
                            }

                            .elementor-widget-heading .elementor-heading-title.elementor-size-medium {
                                font-size: 19px;
                            }

                            .elementor-widget-heading .elementor-heading-title.elementor-size-large {
                                font-size: 29px;
                            }

                            .elementor-widget-heading .elementor-heading-title.elementor-size-xl {
                                font-size: 39px;
                            }

                            .elementor-widget-heading .elementor-heading-title.elementor-size-xxl {
                                font-size: 59px;
                            }
                        </style>
                        <h2 class="elementor-heading-title elementor-size-default">
                            Layanan unggulan Sekolah {{ $sekolah->nama_sekolah }}
                        </h2>
                    </div>
                </div>
                <div class="elementor-element elementor-element-542a5551 elementor-widget elementor-widget-jet-listing-grid"
                    data-id="542a5551" data-element_type="widget" data-settings='{"columns":"8","columns_mobile":"1"}'
                    data-widget_type="jet-listing-grid.default">
                    <div class="elementor-widget-container">
                        <div class="jet-listing-grid jet-listing">
                            <div
                                class="jet-listing-grid__scroll-slider jet-listing-grid__scroll-slider-tablet jet-listing-grid__scroll-slider-mobile">
                                <div class="jet-listing-grid__items grid-col-desk-8 grid-col-tablet-8 grid-col-mobile-1 jet-listing-grid--707"
                                    data-nav='{"enabled":false,"type":null,"more_el":null,"query":[],"widget_settings":{"lisitng_id":707,"posts_num":8,"columns":8,"columns_tablet":8,"columns_mobile":1,"is_archive_template":"","post_status":["publish"],"use_random_posts_num":"","max_posts_num":9,"not_found_message":"Quick Menu Layanan","is_masonry":false,"equal_columns_height":"","use_load_more":"","load_more_id":"","load_more_type":"click","use_custom_post_types":"","custom_post_types":[],"hide_widget_if":"","carousel_enabled":"","slides_to_scroll":"1","arrows":"true","arrow_icon":"fa fa-angle-left","dots":"","autoplay":"true","autoplay_speed":5000,"infinite":"true","center_mode":"","effect":"slide","speed":500,"inject_alternative_items":"","injection_items":[],"scroll_slider_enabled":"yes","scroll_slider_on":["tablet","mobile"],"custom_query":false,"custom_query_id":"","_element_id":""}}'
                                    data-page="1" data-pages="1" data-listing-source="custom_content_type">
                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-16" data-post-id="16">
                                        <style type="text/css">
                                            .jet-listing-dynamic-post-16 .elementor-element.elementor-element-0114adb>.elementor-element-populated {
                                                border-color: #3f95a1;
                                            }
                                        </style>
                                        <div data-elementor-type="jet-listing-items" data-elementor-id="707"
                                            class="elementor elementor-707">
                                            <section
                                                class="elementor-section elementor-top-section elementor-element elementor-element-0f261b5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                data-id="0f261b5" data-element_type="section"
                                                data-settings='{"jet_parallax_layout_list":[]}'>
                                                <div class="elementor-container elementor-column-gap-no">
                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0114adb"
                                                        data-id="0114adb" data-element_type="column">
                                                        <div class="elementor-widget-wrap elementor-element-populated">
                                                            <div class="elementor-element elementor-element-4cc4bce elementor-widget elementor-widget-image"
                                                                data-id="4cc4bce" data-element_type="widget"
                                                                data-widget_type="image.default">
                                                                <div class="elementor-widget-container">
                                                                    <a href="#" onclick="ondev()" disabled>
                                                                        <img decoding="async" width="119"
                                                                            height="119"
                                                                            src="wp-content/uploads/2022/04/ppdb.png"
                                                                            class="attachment-full size-full wp-image-1221"
                                                                            alt="" />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-cdb9b26 elementor-widget elementor-widget-jet-listing-dynamic-link"
                                                                data-id="cdb9b26" data-element_type="widget"
                                                                data-widget_type="jet-listing-dynamic-link.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="jet-listing jet-listing-dynamic-link">
                                                                        <a href="#" onclick="ondev()" disabled
                                                                            class="jet-listing-dynamic-link__link"><span
                                                                                class="jet-listing-dynamic-link__label">PPDB</span></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-15" data-post-id="15">
                                        <style type="text/css">
                                            .jet-listing-dynamic-post-15 .elementor-element.elementor-element-0114adb>.elementor-element-populated {
                                                border-color: #3f95a1;
                                            }
                                        </style>
                                        <div data-elementor-type="jet-listing-items" data-elementor-id="707"
                                            class="elementor elementor-707">
                                            <section
                                                class="elementor-section elementor-top-section elementor-element elementor-element-0f261b5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                data-id="0f261b5" data-element_type="section"
                                                data-settings='{"jet_parallax_layout_list":[]}'>
                                                <div class="elementor-container elementor-column-gap-no">
                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0114adb"
                                                        data-id="0114adb" data-element_type="column">
                                                        <div class="elementor-widget-wrap elementor-element-populated">
                                                            <div class="elementor-element elementor-element-4cc4bce elementor-widget elementor-widget-image"
                                                                data-id="4cc4bce" data-element_type="widget"
                                                                data-widget_type="image.default">
                                                                <div class="elementor-widget-container">
                                                                    <a href="{{ route('visimisiComponent') }}">
                                                                        <img decoding="async" width="119"
                                                                            height="119"
                                                                            src="wp-content/uploads/2022/04/annouce.png"
                                                                            class="attachment-full size-full wp-image-1222"
                                                                            alt="" />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-cdb9b26 elementor-widget elementor-widget-jet-listing-dynamic-link"
                                                                data-id="cdb9b26" data-element_type="widget"
                                                                data-widget_type="jet-listing-dynamic-link.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="jet-listing jet-listing-dynamic-link">
                                                                        <a href="{{ route('visimisiComponent') }}"
                                                                            class="jet-listing-dynamic-link__link"><span
                                                                                class="jet-listing-dynamic-link__label">Visi
                                                                                dan Misi</span></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-14" data-post-id="14">
                                        <style type="text/css">
                                            .jet-listing-dynamic-post-14 .elementor-element.elementor-element-0114adb>.elementor-element-populated {
                                                border-color: #3f95a1;
                                            }
                                        </style>
                                        <div data-elementor-type="jet-listing-items" data-elementor-id="707"
                                            class="elementor elementor-707">
                                            <section
                                                class="elementor-section elementor-top-section elementor-element elementor-element-0f261b5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                data-id="0f261b5" data-element_type="section"
                                                data-settings='{"jet_parallax_layout_list":[]}'>
                                                <div class="elementor-container elementor-column-gap-no">
                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0114adb"
                                                        data-id="0114adb" data-element_type="column">
                                                        <div class="elementor-widget-wrap elementor-element-populated">
                                                            <div class="elementor-element elementor-element-4cc4bce elementor-widget elementor-widget-image"
                                                                data-id="4cc4bce" data-element_type="widget"
                                                                data-widget_type="image.default">
                                                                <div class="elementor-widget-container">
                                                                    <a href="{{ route('downloadComponent') }}">
                                                                        <img loading="lazy" decoding="async"
                                                                            width="119" height="119"
                                                                            src="wp-content/uploads/2022/04/lib.png"
                                                                            class="attachment-full size-full wp-image-1217"
                                                                            alt="" />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-cdb9b26 elementor-widget elementor-widget-jet-listing-dynamic-link"
                                                                data-id="cdb9b26" data-element_type="widget"
                                                                data-widget_type="jet-listing-dynamic-link.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="jet-listing jet-listing-dynamic-link">
                                                                        <a href="{{ route('downloadComponent') }}"
                                                                            class="jet-listing-dynamic-link__link"><span
                                                                                class="jet-listing-dynamic-link__label">Download</span></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-13" data-post-id="13">
                                        <style type="text/css">
                                            .jet-listing-dynamic-post-13 .elementor-element.elementor-element-0114adb>.elementor-element-populated {
                                                border-color: #3f95a1;
                                            }
                                        </style>
                                        <div data-elementor-type="jet-listing-items" data-elementor-id="707"
                                            class="elementor elementor-707">
                                            <section
                                                class="elementor-section elementor-top-section elementor-element elementor-element-0f261b5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                data-id="0f261b5" data-element_type="section"
                                                data-settings='{"jet_parallax_layout_list":[]}'>
                                                <div class="elementor-container elementor-column-gap-no">
                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0114adb"
                                                        data-id="0114adb" data-element_type="column">
                                                        <div class="elementor-widget-wrap elementor-element-populated">
                                                            <div class="elementor-element elementor-element-4cc4bce elementor-widget elementor-widget-image"
                                                                data-id="4cc4bce" data-element_type="widget"
                                                                data-widget_type="image.default">
                                                                <div class="elementor-widget-container">
                                                                    <a href="{{ route('sambutanComponent') }}">
                                                                        <img loading="lazy" decoding="async"
                                                                            width="119" height="119"
                                                                            src="wp-content/uploads/2022/04/sambut.png"
                                                                            class="attachment-full size-full wp-image-1220"
                                                                            alt="" />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-cdb9b26 elementor-widget elementor-widget-jet-listing-dynamic-link"
                                                                data-id="cdb9b26" data-element_type="widget"
                                                                data-widget_type="jet-listing-dynamic-link.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="jet-listing jet-listing-dynamic-link">
                                                                        <a href="{{ route('sambutanComponent') }}"
                                                                            class="jet-listing-dynamic-link__link"><span
                                                                                class="jet-listing-dynamic-link__label">Sambutan</span></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-12" data-post-id="12">
                                        <style type="text/css">
                                            .jet-listing-dynamic-post-12 .elementor-element.elementor-element-0114adb>.elementor-element-populated {
                                                border-color: #3f95a1;
                                            }
                                        </style>
                                        <div data-elementor-type="jet-listing-items" data-elementor-id="707"
                                            class="elementor elementor-707">
                                            <section
                                                class="elementor-section elementor-top-section elementor-element elementor-element-0f261b5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                data-id="0f261b5" data-element_type="section"
                                                data-settings='{"jet_parallax_layout_list":[]}'>
                                                <div class="elementor-container elementor-column-gap-no">
                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0114adb"
                                                        data-id="0114adb" data-element_type="column">
                                                        <div class="elementor-widget-wrap elementor-element-populated">
                                                            <div class="elementor-element elementor-element-4cc4bce elementor-widget elementor-widget-image"
                                                                data-id="4cc4bce" data-element_type="widget"
                                                                data-widget_type="image.default">
                                                                <div class="elementor-widget-container">
                                                                    <a href="{{ route('agendaComponent') }}">
                                                                        <img loading="lazy" decoding="async"
                                                                            width="119" height="119"
                                                                            src="wp-content/uploads/2022/04/agend.png"
                                                                            class="attachment-full size-full wp-image-1219"
                                                                            alt="" />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-cdb9b26 elementor-widget elementor-widget-jet-listing-dynamic-link"
                                                                data-id="cdb9b26" data-element_type="widget"
                                                                data-widget_type="jet-listing-dynamic-link.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="jet-listing jet-listing-dynamic-link">
                                                                        <a href="{{ route('agendaComponent') }}"
                                                                            class="jet-listing-dynamic-link__link"><span
                                                                                class="jet-listing-dynamic-link__label">Agenda</span></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-11" data-post-id="11">
                                        <style type="text/css">
                                            .jet-listing-dynamic-post-11 .elementor-element.elementor-element-0114adb>.elementor-element-populated {
                                                border-color: #3f95a1;
                                            }
                                        </style>
                                        <div data-elementor-type="jet-listing-items" data-elementor-id="707"
                                            class="elementor elementor-707">
                                            <section
                                                class="elementor-section elementor-top-section elementor-element elementor-element-0f261b5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                data-id="0f261b5" data-element_type="section"
                                                data-settings='{"jet_parallax_layout_list":[]}'>
                                                <div class="elementor-container elementor-column-gap-no">
                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0114adb"
                                                        data-id="0114adb" data-element_type="column">
                                                        <div class="elementor-widget-wrap elementor-element-populated">
                                                            <div class="elementor-element elementor-element-4cc4bce elementor-widget elementor-widget-image"
                                                                data-id="4cc4bce" data-element_type="widget"
                                                                data-widget_type="image.default">
                                                                <div class="elementor-widget-container">
                                                                    <a href="{{ route('pengumumanComponent') }}">
                                                                        <img decoding="async" width="119"
                                                                            height="119"
                                                                            src="wp-content/uploads/2022/04/annouce.png"
                                                                            class="attachment-full size-full wp-image-1222"
                                                                            alt="" />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-cdb9b26 elementor-widget elementor-widget-jet-listing-dynamic-link"
                                                                data-id="cdb9b26" data-element_type="widget"
                                                                data-widget_type="jet-listing-dynamic-link.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="jet-listing jet-listing-dynamic-link">
                                                                        <a href="{{ route('pengumumanComponent') }}"
                                                                            class="jet-listing-dynamic-link__link"><span
                                                                                class="jet-listing-dynamic-link__label">Pengumuman</span></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-10" data-post-id="10">
                                        <style type="text/css">
                                            .jet-listing-dynamic-post-10 .elementor-element.elementor-element-0114adb>.elementor-element-populated {
                                                border-color: #3f95a1;
                                            }
                                        </style>
                                        <div data-elementor-type="jet-listing-items" data-elementor-id="707"
                                            class="elementor elementor-707">
                                            <section
                                                class="elementor-section elementor-top-section elementor-element elementor-element-0f261b5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                data-id="0f261b5" data-element_type="section"
                                                data-settings='{"jet_parallax_layout_list":[]}'>
                                                <div class="elementor-container elementor-column-gap-no">
                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0114adb"
                                                        data-id="0114adb" data-element_type="column">
                                                        <div class="elementor-widget-wrap elementor-element-populated">
                                                            <div class="elementor-element elementor-element-4cc4bce elementor-widget elementor-widget-image"
                                                                data-id="4cc4bce" data-element_type="widget"
                                                                data-widget_type="image.default">
                                                                <div class="elementor-widget-container">
                                                                    <a href="{{ route('eskulComponent') }}">
                                                                        <img loading="lazy" decoding="async"
                                                                            width="119" height="119"
                                                                            src="wp-content/uploads/2022/04/eskul.png"
                                                                            class="attachment-full size-full wp-image-1223"
                                                                            alt="" />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-cdb9b26 elementor-widget elementor-widget-jet-listing-dynamic-link"
                                                                data-id="cdb9b26" data-element_type="widget"
                                                                data-widget_type="jet-listing-dynamic-link.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="jet-listing jet-listing-dynamic-link">
                                                                        <a href="{{ route('eskulComponent') }}"
                                                                            class="jet-listing-dynamic-link__link"><span
                                                                                class="jet-listing-dynamic-link__label">Ekstrakurikuler</span></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-9" data-post-id="9">
                                        <style type="text/css">
                                            .jet-listing-dynamic-post-9 .elementor-element.elementor-element-0114adb>.elementor-element-populated {
                                                border-color: #3f95a1;
                                            }
                                        </style>
                                        <div data-elementor-type="jet-listing-items" data-elementor-id="707"
                                            class="elementor elementor-707">
                                            <section
                                                class="elementor-section elementor-top-section elementor-element elementor-element-0f261b5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                data-id="0f261b5" data-element_type="section"
                                                data-settings='{"jet_parallax_layout_list":[]}'>
                                                <div class="elementor-container elementor-column-gap-no">
                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0114adb"
                                                        data-id="0114adb" data-element_type="column">
                                                        <div class="elementor-widget-wrap elementor-element-populated">
                                                            <div class="elementor-element elementor-element-4cc4bce elementor-widget elementor-widget-image"
                                                                data-id="4cc4bce" data-element_type="widget"
                                                                data-widget_type="image.default">
                                                                <div class="elementor-widget-container">
                                                                    <a href="{{ route('prestasiComponent') }}">
                                                                        <img loading="lazy" decoding="async"
                                                                            width="119" height="119"
                                                                            src="wp-content/uploads/2022/04/prest.png"
                                                                            class="attachment-full size-full wp-image-1218"
                                                                            alt="" />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="elementor-element elementor-element-cdb9b26 elementor-widget elementor-widget-jet-listing-dynamic-link"
                                                                data-id="cdb9b26" data-element_type="widget"
                                                                data-widget_type="jet-listing-dynamic-link.default">
                                                                <div class="elementor-widget-container">
                                                                    <div class="jet-listing jet-listing-dynamic-link">
                                                                        <a href="{{ route('prestasiComponent') }}"
                                                                            class="jet-listing-dynamic-link__link"><span
                                                                                class="jet-listing-dynamic-link__label">Prestasi</span></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    function ondev() {
        Swal.fire({
            icon: 'error',
            title: '',
            text: 'fitur sedang dalam pengembangan.',
        });
    }
</script>
