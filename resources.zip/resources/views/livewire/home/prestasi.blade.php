<section
    class="elementor-section elementor-top-section elementor-element elementor-element-343b83a8 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="343b83a8" data-element_type="section"
    data-settings='{"background_background":"classic","jet_parallax_layout_list":[{"_id":"998e88b","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-144cfb62"
            data-id="144cfb62" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <section
                    class="elementor-section elementor-inner-section elementor-element elementor-element-53cc8760 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="53cc8760" data-element_type="section"
                    data-settings='{"jet_parallax_layout_list":[{"_id":"ff9d372","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-27c74da2"
                            data-id="27c74da2" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-592097e5 elementor-widget elementor-widget-heading"
                                    data-id="592097e5" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Prestasi
                                        </h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-6058b54f elementor-widget elementor-widget-heading"
                                    data-id="6058b54f" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Prestasi Sekolah {{ $sekolah->nama_sekolah }}
                                        </h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-48bd20d2"
                            data-id="48bd20d2" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-2b9edfa5 elementor-view-default elementor-widget elementor-widget-icon"
                                    data-id="2b9edfa5" data-element_type="widget" data-widget_type="icon.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-icon-wrapper">
                                            <a class="elementor-icon" href="{{ route('prestasiComponent') }}">
                                                <i aria-hidden="true" class="fas fa-chevron-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <div class="elementor-element elementor-element-8573030 elementor-widget elementor-widget-jet-listing-grid"
                    data-id="8573030" data-element_type="widget" data-settings='{"columns":3}'
                    data-widget_type="jet-listing-grid.default">
                    <div class="elementor-widget-container">
                        <div class="jet-listing-grid jet-listing">
                            <div
                                class="jet-listing-grid__scroll-slider jet-listing-grid__scroll-slider-tablet jet-listing-grid__scroll-slider-mobile">
                                <div class="jet-listing-grid__items grid-col-desk-3 grid-col-tablet-3 grid-col-mobile-3 jet-listing-grid--18"
                                    data-nav='{"enabled":false,"type":null,"more_el":null,"query":[],"widget_settings":{"lisitng_id":18,"posts_num":3,"columns":3,"columns_tablet":3,"columns_mobile":3,"is_archive_template":"","post_status":["publish"],"use_random_posts_num":"","max_posts_num":9,"not_found_message":"Tidak ada prestasi","is_masonry":false,"equal_columns_height":"","use_load_more":"","load_more_id":"","load_more_type":"click","use_custom_post_types":"","custom_post_types":[],"hide_widget_if":"","carousel_enabled":"","slides_to_scroll":"1","arrows":"true","arrow_icon":"fa fa-angle-left","dots":"","autoplay":"true","autoplay_speed":5000,"infinite":"true","center_mode":"","effect":"slide","speed":500,"inject_alternative_items":"","injection_items":[],"scroll_slider_enabled":"yes","scroll_slider_on":["tablet","mobile"],"custom_query":false,"custom_query_id":"","_element_id":""}}'
                                    data-page="1" data-pages="1" data-listing-source="posts">
                                    @foreach ($prestasi as $item)
                                        <div class="jet-listing-grid__item jet-listing-dynamic-post-770"
                                            data-post-id="770">
                                            <style type="text/css">
                                                .jet-listing-dynamic-post-770 .elementor-element.elementor-element-5508ab8 .jet-listing-dynamic-terms__link {
                                                    background-color: #3f95a1;
                                                }

                                                .jet-listing-dynamic-post-770 .elementor-element.elementor-element-5508ab8 .jet-listing-dynamic-terms__link:hover {
                                                    background-color: #ffa800;
                                                }
                                            </style>
                                            <div data-elementor-type="jet-listing-items" data-elementor-id="18"
                                                class="elementor elementor-18">
                                                <section
                                                    class="elementor-section elementor-top-section elementor-element elementor-element-9f77703 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                    data-id="9f77703" data-element_type="section"
                                                    data-settings='{"jet_parallax_layout_list":[{"jet_parallax_layout_image":{"url":"","id":"","size":""},"_id":"fb4688d","jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                                                    <div class="elementor-container elementor-column-gap-default">
                                                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b46c664"
                                                            data-id="b46c664" data-element_type="column">
                                                            <div
                                                                class="elementor-widget-wrap elementor-element-populated">
                                                                <div class="elementor-element elementor-element-be04952 elementor-widget elementor-widget-image"
                                                                    data-id="be04952" data-element_type="widget"
                                                                    data-widget_type="image.default">
                                                                    <div class="elementor-widget-container">
                                                                        <a
                                                                            href="{{ route('prestasiDetailComponent', $item->slug) }}">
                                                                            <img width="640" height="426"
                                                                                src="{{ asset($item->thumbnail) }}"
                                                                                class="attachment-full size-full wp-image-1204"
                                                                                alt="{{ $item->judul }}"
                                                                                sizes="(max-width: 640px) 100vw, 640px" />
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-5508ab8 elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-jet-listing-dynamic-terms"
                                                                    data-id="5508ab8" data-element_type="widget"
                                                                    data-settings='{"_position":"absolute"}'
                                                                    data-widget_type="jet-listing-dynamic-terms.default">
                                                                    <div class="elementor-widget-container">
                                                                        <div
                                                                            class="jet-listing jet-listing-dynamic-terms">
                                                                            <span
                                                                                class="jet-listing-dynamic-terms__link">Siswa</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-1cc425b elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                    data-id="1cc425b" data-element_type="widget"
                                                                    data-widget_type="jet-listing-dynamic-field.default">
                                                                    <div class="elementor-widget-container">
                                                                        <div
                                                                            class="jet-listing jet-listing-dynamic-field display-inline">
                                                                            <div
                                                                                class="jet-listing-dynamic-field__inline-wrap">
                                                                                <div
                                                                                    class="jet-listing-dynamic-field__content">
                                                                                    {{ $item->judul }}
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section>
                                            </div>
                                        </div>
                                    @endforeach

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
