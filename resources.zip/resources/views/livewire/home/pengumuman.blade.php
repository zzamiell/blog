<section
    class="elementor-section elementor-top-section elementor-element elementor-element-5d7dfbf elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="5d7dfbf" data-element_type="section"
    data-settings='{"background_background":"classic","jet_parallax_layout_list":[{"_id":"998e88b","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
    <div class="elementor-background-overlay"></div>
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-eb8c6a1"
            data-id="eb8c6a1" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <section
                    class="elementor-section elementor-inner-section elementor-element elementor-element-2243412 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="2243412" data-element_type="section"
                    data-settings='{"jet_parallax_layout_list":[{"_id":"ff9d372","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5c0a192"
                            data-id="5c0a192" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-e7e6753 elementor-widget elementor-widget-heading"
                                    data-id="e7e6753" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Pengumuman
                                        </h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-98078e4 elementor-widget elementor-widget-heading"
                                    data-id="98078e4" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Pengumuman Sekolah {{ $sekolah->nama_sekolah }}
                                        </h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4e85f06"
                            data-id="4e85f06" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-35cefdc elementor-view-default elementor-widget elementor-widget-icon"
                                    data-id="35cefdc" data-element_type="widget" data-widget_type="icon.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-icon-wrapper">
                                            <a class="elementor-icon" href="{{ route('pengumumanComponent') }}">
                                                <i aria-hidden="true" class="fas fa-chevron-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <div class="elementor-element elementor-element-0ef870e elementor-widget elementor-widget-jet-listing-grid"
                    data-id="0ef870e" data-element_type="widget" data-settings='{"columns":3}'
                    data-widget_type="jet-listing-grid.default">
                    <div class="elementor-widget-container">
                        <div class="jet-listing-grid jet-listing">
                            <div
                                class="jet-listing-grid__scroll-slider jet-listing-grid__scroll-slider-tablet jet-listing-grid__scroll-slider-mobile">
                                <div class="jet-listing-grid__items grid-col-desk-3 grid-col-tablet-3 grid-col-mobile-3 jet-listing-grid--13"
                                    data-nav='{"enabled":false,"type":null,"more_el":null,"query":[],"widget_settings":{"lisitng_id":13,"posts_num":3,"columns":3,"columns_tablet":3,"columns_mobile":3,"is_archive_template":"","post_status":["publish"],"use_random_posts_num":"","max_posts_num":9,"not_found_message":"Tidak ada pengumuman","is_masonry":false,"equal_columns_height":"","use_load_more":"","load_more_id":"","load_more_type":"click","use_custom_post_types":"","custom_post_types":[],"hide_widget_if":"","carousel_enabled":"","slides_to_scroll":"1","arrows":"true","arrow_icon":"fa fa-angle-left","dots":"","autoplay":"true","autoplay_speed":5000,"infinite":"true","center_mode":"","effect":"slide","speed":500,"inject_alternative_items":"","injection_items":[],"scroll_slider_enabled":"yes","scroll_slider_on":["tablet","mobile"],"custom_query":false,"custom_query_id":"","_element_id":""}}'
                                    data-page="1" data-pages="1" data-listing-source="posts">
                                    @foreach ($pengumuman as $item)
                                        <div class="jet-listing-grid__item jet-listing-dynamic-post-764"
                                            data-post-id="764">
                                            <style type="text/css">
                                                .jet-listing-dynamic-post-764 .elementor-element.elementor-element-9b5f01f .elementor-button {
                                                    background-color: #3f95a1;
                                                }
                                            </style>
                                            <div data-elementor-type="jet-listing-items" data-elementor-id="13"
                                                class="elementor elementor-13">
                                                <section
                                                    class="elementor-section elementor-top-section elementor-element elementor-element-f67cebd elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                    data-id="f67cebd" data-element_type="section"
                                                    data-settings='{"jet_parallax_layout_list":[{"jet_parallax_layout_image":{"url":"","id":"","size":""},"_id":"fb4688d","jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                                                    <div class="elementor-container elementor-column-gap-default">
                                                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-26a4ec7"
                                                            data-id="26a4ec7" data-element_type="column">
                                                            <div
                                                                class="elementor-widget-wrap elementor-element-populated">
                                                                <div class="elementor-element elementor-element-9b5f01f elementor-align-right elementor-absolute elementor-widget elementor-widget-button"
                                                                    data-id="9b5f01f" data-element_type="widget"
                                                                    data-settings='{"_position":"absolute"}'
                                                                    data-widget_type="button.default">
                                                                    <div class="elementor-widget-container">
                                                                        <div class="elementor-button-wrapper">
                                                                            <a class="elementor-button elementor-button-link elementor-size-xs"
                                                                                href="{{ route('pengumumanComponent') }}">
                                                                                <span
                                                                                    class="elementor-button-content-wrapper">
                                                                                    <span
                                                                                        class="elementor-button-icon elementor-align-icon-left">
                                                                                        <i aria-hidden="true"
                                                                                            class="fas fa-bullhorn"></i>
                                                                                    </span>
                                                                                    <span
                                                                                        class="elementor-button-text">Pengumuman</span>
                                                                                </span>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-f53dc33 elementor-widget elementor-widget-image"
                                                                    data-id="f53dc33" data-element_type="widget"
                                                                    data-widget_type="image.default">
                                                                    <div class="elementor-widget-container">
                                                                        <a
                                                                            href="{{ route('pengumumanDetailComponent', $item->slug) }}">
                                                                            <img width="640" height="424"
                                                                                src="{{ asset($item->thumbnail) }}"
                                                                                class="attachment-full size-full wp-image-1207"
                                                                                alt="{{ $item->judul }}"
                                                                                sizes="(max-width: 640px) 100vw, 640px" />
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-693ee36 elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                    data-id="693ee36" data-element_type="widget"
                                                                    data-widget_type="jet-listing-dynamic-field.default">
                                                                    <div class="elementor-widget-container">
                                                                        <div
                                                                            class="jet-listing jet-listing-dynamic-field display-inline">
                                                                            <div
                                                                                class="jet-listing-dynamic-field__inline-wrap">
                                                                                <div
                                                                                    class="jet-listing-dynamic-field__content">
                                                                                    {{ $item->judul }}
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section>
                                            </div>
                                        </div>
                                    @endforeach
                                    {{-- <div
                              class="jet-listing-grid__item jet-listing-dynamic-post-763"
                              data-post-id="763"
                            >
                              <style type="text/css">
                                .jet-listing-dynamic-post-763
                                  .elementor-element.elementor-element-9b5f01f
                                  .elementor-button {
                                  background-color: #3f95a1;
                                }
                              </style>
                              <div
                                data-elementor-type="jet-listing-items"
                                data-elementor-id="13"
                                class="elementor elementor-13"
                              >
                                <section
                                  class="elementor-section elementor-top-section elementor-element elementor-element-f67cebd elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                  data-id="f67cebd"
                                  data-element_type="section"
                                  data-settings='{"jet_parallax_layout_list":[{"jet_parallax_layout_image":{"url":"","id":"","size":""},"_id":"fb4688d","jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'
                                >
                                  <div
                                    class="elementor-container elementor-column-gap-default"
                                  >
                                    <div
                                      class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-26a4ec7"
                                      data-id="26a4ec7"
                                      data-element_type="column"
                                    >
                                      <div
                                        class="elementor-widget-wrap elementor-element-populated"
                                      >
                                        <div
                                          class="elementor-element elementor-element-9b5f01f elementor-align-right elementor-absolute elementor-widget elementor-widget-button"
                                          data-id="9b5f01f"
                                          data-element_type="widget"
                                          data-settings='{"_position":"absolute"}'
                                          data-widget_type="button.default"
                                        >
                                          <div
                                            class="elementor-widget-container"
                                          >
                                            <div
                                              class="elementor-button-wrapper"
                                            >
                                              <a
                                                class="elementor-button elementor-button-link elementor-size-xs"
                                                href="pengumuman/jadwal-luring-kelas-iv/index.html"
                                              >
                                                <span
                                                  class="elementor-button-content-wrapper"
                                                >
                                                  <span
                                                    class="elementor-button-icon elementor-align-icon-left"
                                                  >
                                                    <i
                                                      aria-hidden="true"
                                                      class="fas fa-bullhorn"
                                                    ></i>
                                                  </span>
                                                  <span
                                                    class="elementor-button-text"
                                                    >Pengumuman</span
                                                  >
                                                </span>
                                              </a>
                                            </div>
                                          </div>
                                        </div>
                                        <div
                                          class="elementor-element elementor-element-f53dc33 elementor-widget elementor-widget-image"
                                          data-id="f53dc33"
                                          data-element_type="widget"
                                          data-widget_type="image.default"
                                        >
                                          <div
                                            class="elementor-widget-container"
                                          >
                                            <a
                                              href="pengumuman/jadwal-luring-kelas-iv/index.html"
                                            >
                                              <img
                                                loading="lazy"
                                                decoding="async"
                                                width="640"
                                                height="426"
                                                src="wp-content/uploads/2022/04/baca.jpg"
                                                class="attachment-full size-full wp-image-1211"
                                                alt=""
                                                srcset="
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/baca.jpg         640w,
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/baca-300x200.jpg 300w
                                                "
                                                sizes="(max-width: 640px) 100vw, 640px"
                                              />
                                            </a>
                                          </div>
                                        </div>
                                        <div
                                          class="elementor-element elementor-element-693ee36 elementor-widget elementor-widget-jet-listing-dynamic-field"
                                          data-id="693ee36"
                                          data-element_type="widget"
                                          data-widget_type="jet-listing-dynamic-field.default"
                                        >
                                          <div
                                            class="elementor-widget-container"
                                          >
                                            <div
                                              class="jet-listing jet-listing-dynamic-field display-inline"
                                            >
                                              <div
                                                class="jet-listing-dynamic-field__inline-wrap"
                                              >
                                                <div
                                                  class="jet-listing-dynamic-field__content"
                                                >
                                                  Jadwal Luring Kelas IV
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </section>
                              </div>
                            </div>
                            <div
                              class="jet-listing-grid__item jet-listing-dynamic-post-762"
                              data-post-id="762"
                            >
                              <style type="text/css">
                                .jet-listing-dynamic-post-762
                                  .elementor-element.elementor-element-9b5f01f
                                  .elementor-button {
                                  background-color: #3f95a1;
                                }
                              </style>
                              <div
                                data-elementor-type="jet-listing-items"
                                data-elementor-id="13"
                                class="elementor elementor-13"
                              >
                                <section
                                  class="elementor-section elementor-top-section elementor-element elementor-element-f67cebd elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                  data-id="f67cebd"
                                  data-element_type="section"
                                  data-settings='{"jet_parallax_layout_list":[{"jet_parallax_layout_image":{"url":"","id":"","size":""},"_id":"fb4688d","jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'
                                >
                                  <div
                                    class="elementor-container elementor-column-gap-default"
                                  >
                                    <div
                                      class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-26a4ec7"
                                      data-id="26a4ec7"
                                      data-element_type="column"
                                    >
                                      <div
                                        class="elementor-widget-wrap elementor-element-populated"
                                      >
                                        <div
                                          class="elementor-element elementor-element-9b5f01f elementor-align-right elementor-absolute elementor-widget elementor-widget-button"
                                          data-id="9b5f01f"
                                          data-element_type="widget"
                                          data-settings='{"_position":"absolute"}'
                                          data-widget_type="button.default"
                                        >
                                          <div
                                            class="elementor-widget-container"
                                          >
                                            <div
                                              class="elementor-button-wrapper"
                                            >
                                              <a
                                                class="elementor-button elementor-button-link elementor-size-xs"
                                                href="pengumuman/stop-bullying/index.html"
                                              >
                                                <span
                                                  class="elementor-button-content-wrapper"
                                                >
                                                  <span
                                                    class="elementor-button-icon elementor-align-icon-left"
                                                  >
                                                    <i
                                                      aria-hidden="true"
                                                      class="fas fa-bullhorn"
                                                    ></i>
                                                  </span>
                                                  <span
                                                    class="elementor-button-text"
                                                    >Pengumuman</span
                                                  >
                                                </span>
                                              </a>
                                            </div>
                                          </div>
                                        </div>
                                        <div
                                          class="elementor-element elementor-element-f53dc33 elementor-widget elementor-widget-image"
                                          data-id="f53dc33"
                                          data-element_type="widget"
                                          data-widget_type="image.default"
                                        >
                                          <div
                                            class="elementor-widget-container"
                                          >
                                            <a
                                              href="pengumuman/stop-bullying/index.html"
                                            >
                                              <img
                                                loading="lazy"
                                                decoding="async"
                                                width="640"
                                                height="426"
                                                src="wp-content/uploads/2022/04/diskus.jpg"
                                                class="attachment-full size-full wp-image-1205"
                                                alt=""
                                                srcset="
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/diskus.jpg         640w,
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/diskus-300x200.jpg 300w
                                                "
                                                sizes="(max-width: 640px) 100vw, 640px"
                                              />
                                            </a>
                                          </div>
                                        </div>
                                        <div
                                          class="elementor-element elementor-element-693ee36 elementor-widget elementor-widget-jet-listing-dynamic-field"
                                          data-id="693ee36"
                                          data-element_type="widget"
                                          data-widget_type="jet-listing-dynamic-field.default"
                                        >
                                          <div
                                            class="elementor-widget-container"
                                          >
                                            <div
                                              class="jet-listing jet-listing-dynamic-field display-inline"
                                            >
                                              <div
                                                class="jet-listing-dynamic-field__inline-wrap"
                                              >
                                                <div
                                                  class="jet-listing-dynamic-field__content"
                                                >
                                                  Stop Bullying
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </section>
                              </div>
                            </div> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
