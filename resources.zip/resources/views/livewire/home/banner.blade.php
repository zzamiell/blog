<section
    class="elementor-section elementor-top-section elementor-element elementor-element-29a81b3 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="29a81b3" data-element_type="section"
    data-settings='{"jet_parallax_layout_list":[{"_id":"118aab7","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-468fd1a5"
            data-id="468fd1a5" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-50b66461 elementor-widget elementor-widget-jet-carousel"
                    data-id="50b66461" data-element_type="widget"
                    data-settings='{"slides_to_show_tablet":"2","slides_to_show_mobile":"1","slides_to_scroll_mobile":"1","slides_to_show":"2","slides_to_scroll":"1"}'
                    data-widget_type="jet-carousel.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-jet-carousel jet-elements">
                            <div class="jet-carousel-wrap">
                                <div class="jet-carousel"
                                    data-slider_options='{"autoplaySpeed":5000,"autoplay":true,"infinite":true,"centerMode":false,"pauseOnHover":false,"speed":500,"arrows":false,"dots":true,"variableWidth":false,"prevArrow":".jet-carousel__prev-arrow-50b66461","nextArrow":".jet-carousel__next-arrow-50b66461","rtl":false,"fractionNav":false}'
                                    dir="ltr">
                                    <div class="elementor-slick-slider">
                                        @foreach ($banner as $item)
                                            <div class="jet-carousel__item">
                                                <div class="jet-carousel__item-inner">
                                                    <img src="{{ asset($item->banner) }}" class="jet-carousel__item-img"
                                                        alt="featured" />
                                                    <div class="jet-carousel__content"></div>
                                                </div>
                                            </div>
                                        @endforeach

                                        {{-- <div class="jet-carousel__item">
                                            <div class="jet-carousel__item-inner">
                                                <img decoding="async" src="wp-content/uploads/2022/04/featured.jpg"
                                                    class="jet-carousel__item-img" alt="featured" loading="lazy" />
                                                <div class="jet-carousel__content"></div>
                                            </div>
                                        </div>

                                        <div class="jet-carousel__item">
                                            <div class="jet-carousel__item-inner">
                                                <img decoding="async" src="wp-content/uploads/2022/04/featured.jpg"
                                                    class="jet-carousel__item-img" alt="featured" loading="lazy" />
                                                <div class="jet-carousel__content"></div>
                                            </div>
                                        </div>

                                        <div class="jet-carousel__item">
                                            <div class="jet-carousel__item-inner">
                                                <img decoding="async" src="wp-content/uploads/2022/04/featured.jpg"
                                                    class="jet-carousel__item-img" alt="featured" loading="lazy" />
                                                <div class="jet-carousel__content"></div>
                                            </div>
                                        </div>

                                        <div class="jet-carousel__item">
                                            <div class="jet-carousel__item-inner">
                                                <img decoding="async" src="wp-content/uploads/2022/04/oto.jpg"
                                                    class="jet-carousel__item-img" alt="oto" loading="lazy" />
                                                <div class="jet-carousel__content"></div>
                                            </div>
                                        </div> --}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
