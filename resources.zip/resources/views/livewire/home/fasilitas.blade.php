<section
    class="elementor-section elementor-top-section elementor-element elementor-element-c5b6bd8 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="c5b6bd8" data-element_type="section"
    data-settings='{"background_background":"classic","jet_parallax_layout_list":[{"_id":"998e88b","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-07a2578"
            data-id="07a2578" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <section
                    class="elementor-section elementor-inner-section elementor-element elementor-element-de8dec3 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="de8dec3" data-element_type="section"
                    data-settings='{"jet_parallax_layout_list":[{"_id":"ff9d372","jet_parallax_layout_image":{"url":"","id":"","size":""},"jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-77a2735"
                            data-id="77a2735" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-13b0fd7 elementor-widget elementor-widget-heading"
                                    data-id="13b0fd7" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Fasilitas
                                        </h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-78b8783 elementor-widget elementor-widget-heading"
                                    data-id="78b8783" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">
                                            Fasilitas dari Sekolah {{ $sekolah->nama_sekolah }}
                                        </h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-03cd38d"
                            data-id="03cd38d" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-00e182f elementor-view-default elementor-widget elementor-widget-icon"
                                    data-id="00e182f" data-element_type="widget" data-widget_type="icon.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-icon-wrapper">
                                            <a class="elementor-icon" href="{{ route('fasilitasComponent') }}">
                                                <i aria-hidden="true" class="fas fa-chevron-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <div class="elementor-element elementor-element-3dc1507 elementor-widget elementor-widget-jet-listing-grid"
                    data-id="3dc1507" data-element_type="widget" data-settings='{"columns":3}'
                    data-widget_type="jet-listing-grid.default">
                    <div class="elementor-widget-container">
                        <div class="jet-listing-grid jet-listing">
                            <div
                                class="jet-listing-grid__scroll-slider jet-listing-grid__scroll-slider-tablet jet-listing-grid__scroll-slider-mobile">
                                <div class="jet-listing-grid__items grid-col-desk-3 grid-col-tablet-3 grid-col-mobile-3 jet-listing-grid--16"
                                    data-nav='{"enabled":false,"type":null,"more_el":null,"query":[],"widget_settings":{"lisitng_id":16,"posts_num":3,"columns":3,"columns_tablet":3,"columns_mobile":3,"is_archive_template":"","post_status":["publish"],"use_random_posts_num":"","max_posts_num":9,"not_found_message":"Tidak ada fasilitas","is_masonry":false,"equal_columns_height":"","use_load_more":"","load_more_id":"","load_more_type":"click","use_custom_post_types":"","custom_post_types":[],"hide_widget_if":"","carousel_enabled":"","slides_to_scroll":"1","arrows":"true","arrow_icon":"fa fa-angle-left","dots":"","autoplay":"true","autoplay_speed":5000,"infinite":"true","center_mode":"","effect":"slide","speed":500,"inject_alternative_items":"","injection_items":[],"scroll_slider_enabled":"yes","scroll_slider_on":["tablet","mobile"],"custom_query":false,"custom_query_id":"","_element_id":""}}'
                                    data-page="1" data-pages="2" data-listing-source="posts">
                                    @foreach ($fasilitas as $item)
                                        <div class="jet-listing-grid__item jet-listing-dynamic-post-1377"
                                            data-post-id="1377">
                                            <div data-elementor-type="jet-listing-items" data-elementor-id="16"
                                                class="elementor elementor-16">
                                                <section
                                                    class="elementor-section elementor-top-section elementor-element elementor-element-d50931f elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                    data-id="d50931f" data-element_type="section"
                                                    data-settings='{"jet_parallax_layout_list":[{"jet_parallax_layout_image":{"url":"","id":"","size":""},"_id":"fb4688d","jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'>
                                                    <div class="elementor-container elementor-column-gap-default">
                                                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d758307"
                                                            data-id="d758307" data-element_type="column">
                                                            <div
                                                                class="elementor-widget-wrap elementor-element-populated">
                                                                <div class="elementor-element elementor-element-ac610b5 elementor-widget elementor-widget-image"
                                                                    data-id="ac610b5" data-element_type="widget"
                                                                    data-widget_type="image.default">
                                                                    <div class="elementor-widget-container">
                                                                        <a
                                                                            href="{{ route('fasilitasDetailComponent', $item->slug) }}">
                                                                            <img width="640" height="426"
                                                                                src="{{ $item->thumbnail }}"
                                                                                class="attachment-full size-full wp-image-1210"
                                                                                alt=" {{ $item->judul }}"
                                                                                sizes="(max-width: 640px) 100vw, 640px" />
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-fdfff8f elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                    data-id="fdfff8f" data-element_type="widget"
                                                                    data-settings='{"_position":"absolute"}'
                                                                    data-widget_type="jet-listing-dynamic-field.default">
                                                                    <div class="elementor-widget-container">
                                                                        <div
                                                                            class="jet-listing jet-listing-dynamic-field display-inline">
                                                                            <div
                                                                                class="jet-listing-dynamic-field__inline-wrap">
                                                                                <div
                                                                                    class="jet-listing-dynamic-field__content">
                                                                                    {{ $item->judul }}
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section>
                                            </div>
                                        </div>
                                    @endforeach
                                    {{-- <div
                              class="jet-listing-grid__item jet-listing-dynamic-post-1278"
                              data-post-id="1278"
                            >
                              <div
                                data-elementor-type="jet-listing-items"
                                data-elementor-id="16"
                                class="elementor elementor-16"
                              >
                                <section
                                  class="elementor-section elementor-top-section elementor-element elementor-element-d50931f elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                  data-id="d50931f"
                                  data-element_type="section"
                                  data-settings='{"jet_parallax_layout_list":[{"jet_parallax_layout_image":{"url":"","id":"","size":""},"_id":"fb4688d","jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'
                                >
                                  <div
                                    class="elementor-container elementor-column-gap-default"
                                  >
                                    <div
                                      class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d758307"
                                      data-id="d758307"
                                      data-element_type="column"
                                    >
                                      <div
                                        class="elementor-widget-wrap elementor-element-populated"
                                      >
                                        <div
                                          class="elementor-element elementor-element-ac610b5 elementor-widget elementor-widget-image"
                                          data-id="ac610b5"
                                          data-element_type="widget"
                                          data-widget_type="image.default"
                                        >
                                          <div
                                            class="elementor-widget-container"
                                          >
                                            <a
                                              href="fasilitas/lab-kimia/index.html"
                                            >
                                              <img
                                                loading="lazy"
                                                decoding="async"
                                                width="640"
                                                height="427"
                                                src="wp-content/uploads/2022/04/lab.jpg"
                                                class="attachment-full size-full wp-image-1212"
                                                alt=""
                                                srcset="
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/lab.jpg         640w,
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/lab-300x200.jpg 300w
                                                "
                                                sizes="(max-width: 640px) 100vw, 640px"
                                              />
                                            </a>
                                          </div>
                                        </div>
                                        <div
                                          class="elementor-element elementor-element-fdfff8f elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-jet-listing-dynamic-field"
                                          data-id="fdfff8f"
                                          data-element_type="widget"
                                          data-settings='{"_position":"absolute"}'
                                          data-widget_type="jet-listing-dynamic-field.default"
                                        >
                                          <div
                                            class="elementor-widget-container"
                                          >
                                            <div
                                              class="jet-listing jet-listing-dynamic-field display-inline"
                                            >
                                              <div
                                                class="jet-listing-dynamic-field__inline-wrap"
                                              >
                                                <div
                                                  class="jet-listing-dynamic-field__content"
                                                >
                                                  Lab Kimia
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </section>
                              </div>
                            </div>
                            <div
                              class="jet-listing-grid__item jet-listing-dynamic-post-1277"
                              data-post-id="1277"
                            >
                              <div
                                data-elementor-type="jet-listing-items"
                                data-elementor-id="16"
                                class="elementor elementor-16"
                              >
                                <section
                                  class="elementor-section elementor-top-section elementor-element elementor-element-d50931f elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                  data-id="d50931f"
                                  data-element_type="section"
                                  data-settings='{"jet_parallax_layout_list":[{"jet_parallax_layout_image":{"url":"","id":"","size":""},"_id":"fb4688d","jet_parallax_layout_image_tablet":{"url":"","id":"","size":""},"jet_parallax_layout_image_mobile":{"url":"","id":"","size":""},"jet_parallax_layout_speed":{"unit":"%","size":50,"sizes":[]},"jet_parallax_layout_type":"scroll","jet_parallax_layout_direction":null,"jet_parallax_layout_fx_direction":null,"jet_parallax_layout_z_index":"","jet_parallax_layout_bg_x":50,"jet_parallax_layout_bg_x_tablet":"","jet_parallax_layout_bg_x_mobile":"","jet_parallax_layout_bg_y":50,"jet_parallax_layout_bg_y_tablet":"","jet_parallax_layout_bg_y_mobile":"","jet_parallax_layout_bg_size":"auto","jet_parallax_layout_bg_size_tablet":"","jet_parallax_layout_bg_size_mobile":"","jet_parallax_layout_animation_prop":"transform","jet_parallax_layout_on":["desktop","tablet"]}]}'
                                >
                                  <div
                                    class="elementor-container elementor-column-gap-default"
                                  >
                                    <div
                                      class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d758307"
                                      data-id="d758307"
                                      data-element_type="column"
                                    >
                                      <div
                                        class="elementor-widget-wrap elementor-element-populated"
                                      >
                                        <div
                                          class="elementor-element elementor-element-ac610b5 elementor-widget elementor-widget-image"
                                          data-id="ac610b5"
                                          data-element_type="widget"
                                          data-widget_type="image.default"
                                        >
                                          <div
                                            class="elementor-widget-container"
                                          >
                                            <a
                                              href="fasilitas/perpustakaan-ceria/index.html"
                                            >
                                              <img
                                                loading="lazy"
                                                decoding="async"
                                                width="640"
                                                height="426"
                                                src="wp-content/uploads/2022/04/baca.jpg"
                                                class="attachment-full size-full wp-image-1211"
                                                alt=""
                                                srcset="
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/baca.jpg         640w,
                                                  https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/baca-300x200.jpg 300w
                                                "
                                                sizes="(max-width: 640px) 100vw, 640px"
                                              />
                                            </a>
                                          </div>
                                        </div>
                                        <div
                                          class="elementor-element elementor-element-fdfff8f elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-jet-listing-dynamic-field"
                                          data-id="fdfff8f"
                                          data-element_type="widget"
                                          data-settings='{"_position":"absolute"}'
                                          data-widget_type="jet-listing-dynamic-field.default"
                                        >
                                          <div
                                            class="elementor-widget-container"
                                          >
                                            <div
                                              class="jet-listing jet-listing-dynamic-field display-inline"
                                            >
                                              <div
                                                class="jet-listing-dynamic-field__inline-wrap"
                                              >
                                                <div
                                                  class="jet-listing-dynamic-field__content"
                                                >
                                                  Perpustakaan Ceria
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </section>
                              </div>
                            </div> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
