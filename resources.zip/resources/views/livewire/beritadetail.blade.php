<div data-elementor-type="single-post" data-elementor-id="136"
    class="elementor elementor-136 elementor-location-single post-1272 post type-post status-publish format-standard has-post-thumbnail hentry category-berita">
    <div class="elementor-section-wrap">
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-55aa2b41 elementor-section-boxed elementor-section-height-default elementor-section-height-default jet-parallax-section"
            data-id="55aa2b41" data-element_type="section"
            data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;_id&quot;:&quot;94b5e2d&quot;,&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}],&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-75946497"
                    data-id="75946497" data-element_type="column"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-widget-wrap">
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-2d828a38 elementor-section-boxed elementor-section-height-default elementor-section-height-default jet-parallax-section"
            data-id="2d828a38" data-element_type="section"
            data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;_id&quot;:&quot;2506af1&quot;,&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}],&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-348e8f98"
                    data-id="348e8f98" data-element_type="column"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-124de14f elementor-section-boxed elementor-section-height-default elementor-section-height-default jet-parallax-section"
                            data-id="124de14f" data-element_type="section"
                            data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;jet_parallax_layout_list&quot;:[{&quot;_id&quot;:&quot;a741281&quot;,&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                            <div class="elementor-container elementor-column-gap-no">
                                <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-3fd74c6f"
                                    data-id="3fd74c6f" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-44f54ece elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                                            data-id="44f54ece" data-element_type="widget"
                                            data-widget_type="divider.default">
                                            <div class="elementor-widget-container">
                                                <style>
                                                    /*! elementor - v3.21.0 - 26-05-2024 */
                                                    .elementor-widget-divider {
                                                        --divider-border-style: none;
                                                        --divider-border-width: 1px;
                                                        --divider-color: #0c0d0e;
                                                        --divider-icon-size: 20px;
                                                        --divider-element-spacing: 10px;
                                                        --divider-pattern-height: 24px;
                                                        --divider-pattern-size: 20px;
                                                        --divider-pattern-url: none;
                                                        --divider-pattern-repeat: repeat-x
                                                    }

                                                    .elementor-widget-divider .elementor-divider {
                                                        display: flex
                                                    }

                                                    .elementor-widget-divider .elementor-divider__text {
                                                        font-size: 15px;
                                                        line-height: 1;
                                                        max-width: 95%
                                                    }

                                                    .elementor-widget-divider .elementor-divider__element {
                                                        margin: 0 var(--divider-element-spacing);
                                                        flex-shrink: 0
                                                    }

                                                    .elementor-widget-divider .elementor-icon {
                                                        font-size: var(--divider-icon-size)
                                                    }

                                                    .elementor-widget-divider .elementor-divider-separator {
                                                        display: flex;
                                                        margin: 0;
                                                        direction: ltr
                                                    }

                                                    .elementor-widget-divider--view-line_icon .elementor-divider-separator,
                                                    .elementor-widget-divider--view-line_text .elementor-divider-separator {
                                                        align-items: center
                                                    }

                                                    .elementor-widget-divider--view-line_icon .elementor-divider-separator:after,
                                                    .elementor-widget-divider--view-line_icon .elementor-divider-separator:before,
                                                    .elementor-widget-divider--view-line_text .elementor-divider-separator:after,
                                                    .elementor-widget-divider--view-line_text .elementor-divider-separator:before {
                                                        display: block;
                                                        content: "";
                                                        border-block-end: 0;
                                                        flex-grow: 1;
                                                        border-block-start: var(--divider-border-width) var(--divider-border-style) var(--divider-color)
                                                    }

                                                    .elementor-widget-divider--element-align-left .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type {
                                                        flex-grow: 0;
                                                        flex-shrink: 100
                                                    }

                                                    .elementor-widget-divider--element-align-left .elementor-divider-separator:before {
                                                        content: none
                                                    }

                                                    .elementor-widget-divider--element-align-left .elementor-divider__element {
                                                        margin-left: 0
                                                    }

                                                    .elementor-widget-divider--element-align-right .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type {
                                                        flex-grow: 0;
                                                        flex-shrink: 100
                                                    }

                                                    .elementor-widget-divider--element-align-right .elementor-divider-separator:after {
                                                        content: none
                                                    }

                                                    .elementor-widget-divider--element-align-right .elementor-divider__element {
                                                        margin-right: 0
                                                    }

                                                    .elementor-widget-divider--element-align-start .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type {
                                                        flex-grow: 0;
                                                        flex-shrink: 100
                                                    }

                                                    .elementor-widget-divider--element-align-start .elementor-divider-separator:before {
                                                        content: none
                                                    }

                                                    .elementor-widget-divider--element-align-start .elementor-divider__element {
                                                        margin-inline-start: 0
                                                    }

                                                    .elementor-widget-divider--element-align-end .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type {
                                                        flex-grow: 0;
                                                        flex-shrink: 100
                                                    }

                                                    .elementor-widget-divider--element-align-end .elementor-divider-separator:after {
                                                        content: none
                                                    }

                                                    .elementor-widget-divider--element-align-end .elementor-divider__element {
                                                        margin-inline-end: 0
                                                    }

                                                    .elementor-widget-divider:not(.elementor-widget-divider--view-line_text):not(.elementor-widget-divider--view-line_icon) .elementor-divider-separator {
                                                        border-block-start: var(--divider-border-width) var(--divider-border-style) var(--divider-color)
                                                    }

                                                    .elementor-widget-divider--separator-type-pattern {
                                                        --divider-border-style: none
                                                    }

                                                    .elementor-widget-divider--separator-type-pattern.elementor-widget-divider--view-line .elementor-divider-separator,
                                                    .elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:after,
                                                    .elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:before,
                                                    .elementor-widget-divider--separator-type-pattern:not([class*=elementor-widget-divider--view]) .elementor-divider-separator {
                                                        width: 100%;
                                                        min-height: var(--divider-pattern-height);
                                                        -webkit-mask-size: var(--divider-pattern-size) 100%;
                                                        mask-size: var(--divider-pattern-size) 100%;
                                                        -webkit-mask-repeat: var(--divider-pattern-repeat);
                                                        mask-repeat: var(--divider-pattern-repeat);
                                                        background-color: var(--divider-color);
                                                        -webkit-mask-image: var(--divider-pattern-url);
                                                        mask-image: var(--divider-pattern-url)
                                                    }

                                                    .elementor-widget-divider--no-spacing {
                                                        --divider-pattern-size: auto
                                                    }

                                                    .elementor-widget-divider--bg-round {
                                                        --divider-pattern-repeat: round
                                                    }

                                                    .rtl .elementor-widget-divider .elementor-divider__text {
                                                        direction: rtl
                                                    }

                                                    .e-con-inner>.elementor-widget-divider,
                                                    .e-con>.elementor-widget-divider {
                                                        width: var(--container-widget-width, 100%);
                                                        --flex-grow: var(--container-widget-flex-grow)
                                                    }
                                                </style>
                                                <div class="elementor-divider">
                                                    <span class="elementor-divider-separator">
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row justify-content-center">
                                            <div class="col-md-8">
                                                <img src="{{ asset($artikel->thumbnail) }}" alt="">
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-5e08a826 elementor-icon-list--layout-inline elementor-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                                            data-id="5e08a826" data-element_type="widget"
                                            data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <h3 class="elementor-heading-title elementor-size-default">
                                                    {{ $artikel->judul }}</h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-4036dd27 elementor-section-boxed elementor-section-height-default elementor-section-height-default jet-parallax-section"
            data-id="4036dd27" data-element_type="section"
            data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;_id&quot;:&quot;4fea631&quot;,&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}],&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2149d9c1"
                    data-id="2149d9c1" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-452cb1ef elementor-widget elementor-widget-theme-post-content"
                            data-id="452cb1ef" data-element_type="widget" data-widget_type="theme-post-content.default">
                            <div class="elementor-widget-container">

                                {!! strip_tags($artikel->content) !!}
                            </div>
                        </div>
                        <section
                            class="elementor-section elementor-inner-section elementor-element elementor-element-6b14f0ea elementor-section-boxed elementor-section-height-default elementor-section-height-default jet-parallax-section"
                            data-id="6b14f0ea" data-element_type="section"
                            data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;_id&quot;:&quot;bc05d74&quot;,&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4f82038b"
                                    data-id="4f82038b" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-2114885b elementor-widget elementor-widget-heading"
                                            data-id="2114885b" data-element_type="widget"
                                            data-widget_type="heading.default">
                                            <div class="elementor-widget-container">
                                                <h2 class="elementor-heading-title elementor-size-default">Bagikan :
                                                </h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-7c29b36d"
                                    data-id="7c29b36d" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-1141b4d elementor-share-buttons--view-icon elementor-share-buttons--shape-circle elementor-share-buttons--align-right elementor-share-buttons-tablet--align-center elementor-share-buttons-mobile--align-right elementor-share-buttons--skin-gradient elementor-grid-0 elementor-share-buttons--color-official elementor-widget elementor-widget-share-buttons"
                                            data-id="1141b4d" data-element_type="widget"
                                            data-widget_type="share-buttons.default">
                                            <div class="elementor-widget-container">
                                                <link rel="stylesheet"
                                                    href="{{ asset('wp-content/plugins/elementor-pro/assets/css/widget-share-buttons.min.css') }}">
                                                <div class="elementor-grid p-3">
                                                    <div class="elementor-grid-item">
                                                        padding <div
                                                            class="elementor-share-btn elementor-share-btn_facebook"
                                                            tabindex="0" aria-label="Share on facebook">
                                                            <span class="elementor-share-btn__icon">
                                                                <i class="fab fa-facebook" aria-hidden="true"></i>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-grid-item ml-2" style="padding: 2%">
                                                        <div class="elementor-share-btn elementor-share-btn_twitter"
                                                            tabindex="0" aria-label="Share on twitter">
                                                            <span class="elementor-share-btn__icon">
                                                                <i class="fab fa-twitter" aria-hidden="true"></i>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-grid-item ml-2" style="padding: 2%">
                                                        <div class="elementor-share-btn elementor-share-btn_telegram"
                                                            tabindex="0" aria-label="Share on telegram">
                                                            <span class="elementor-share-btn__icon">
                                                                <i class="fab fa-telegram" aria-hidden="true"></i>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-grid-item ml-2" style="padding: 2%">
                                                        <div class="elementor-share-btn elementor-share-btn_whatsapp"
                                                            tabindex="0" aria-label="Share on whatsapp">
                                                            <span class="elementor-share-btn__icon">
                                                                <i class="fab fa-whatsapp" aria-hidden="true"></i>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="elementor-element elementor-element-5fba2946 elementor-widget elementor-widget-menu-anchor"
                            data-id="5fba2946" data-element_type="widget" data-widget_type="menu-anchor.default">
                            <div class="elementor-widget-container">
                                <style>
                                    /*! elementor - v3.21.0 - 26-05-2024 */
                                    body.elementor-page .elementor-widget-menu-anchor {
                                        margin-bottom: 0
                                    }
                                </style>
                                <div class="elementor-menu-anchor" id="fb"></div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-4ed47f4f elementor-widget elementor-widget-facebook-comments"
                            data-id="4ed47f4f" data-element_type="widget"
                            data-widget_type="facebook-comments.default">
                            <div class="elementor-widget-container">
                                <style>
                                    /*! elementor-pro - v3.7.7 - 20-09-2022 */
                                    .elementor-facebook-widget.fb_iframe_widget,
                                    .elementor-facebook-widget.fb_iframe_widget span {
                                        width: 100% !important
                                    }

                                    .elementor-facebook-widget.fb_iframe_widget iframe {
                                        position: relative;
                                        width: 100% !important
                                    }

                                    .elementor-facebook-widget.fb-like {
                                        height: 1px
                                    }

                                    .elementor-widget-facebook-comments iframe {
                                        width: 100% !important
                                    }
                                </style>
                                <div class="elementor-facebook-widget fb-comments fb_iframe_widget fb_iframe_widget_fluid_desktop"
                                    data-href="https://sekolah.flymotion.my.id?p=1272" data-width="100%"
                                    data-numposts="10" data-order-by="social" style="min-height: 1px; width: 100%;"
                                    fb-xfbml-state="rendered"
                                    fb-iframe-plugin-query="app_id=&amp;container_width=1100&amp;height=100&amp;href=https%3A%2F%2Fsekolah.flymotion.my.id%2F%3Fp%3D1272&amp;locale=id_ID&amp;numposts=10&amp;order_by=social&amp;sdk=joey&amp;version=v2.10&amp;width=">
                                    <span
                                        style="vertical-align: top; width: 100%; height: 0px; overflow: hidden;"><iframe
                                            name="f1742dcb3dce1d615" width="1000px" height="100px"
                                            data-testid="fb:comments Facebook Social Plugin"
                                            title="fb:comments Facebook Social Plugin" frameborder="0"
                                            allowtransparency="true" allowfullscreen="true" scrolling="no"
                                            allow="encrypted-media"
                                            src="https://www.facebook.com/v2.10/plugins/comments.php?app_id=&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fx%2Fconnect%2Fxd_arbiter%2F%3Fversion%3D46%23cb%3Dfb8360d80c48f3e30%26domain%3D%26is_canvas%3Dfalse%26origin%3Dfile%253A%252F%252F%252Ffea3240e73a70d736%26relation%3Dparent.parent&amp;container_width=1100&amp;height=100&amp;href=https%3A%2F%2Fsekolah.flymotion.my.id%2F%3Fp%3D1272&amp;locale=id_ID&amp;numposts=10&amp;order_by=social&amp;sdk=joey&amp;version=v2.10&amp;width="
                                            style="border: none; visibility: visible; width: 0px; height: 0px;"></iframe></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section
            class="elementor-section elementor-top-section elementor-element elementor-element-4dade2ec elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            data-id="4dade2ec" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[]}">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-12165483"
                    data-id="12165483" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-40d56b4d elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                            data-id="40d56b4d" data-element_type="widget" data-widget_type="divider.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-divider">
                                    <span class="elementor-divider-separator">
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-1b973413 elementor-widget elementor-widget-heading"
                            data-id="1b973413" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container">
                                <h2 class="elementor-heading-title elementor-size-default">Artikel Lainnya</h2>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-15fd3ae8 elementor-widget elementor-widget-jet-listing-grid"
                            data-id="15fd3ae8" data-element_type="widget"
                            data-settings="{&quot;columns&quot;:&quot;3&quot;,&quot;columns_tablet&quot;:&quot;3&quot;,&quot;columns_mobile&quot;:&quot;2&quot;}"
                            data-widget_type="jet-listing-grid.default">
                            <div class="elementor-widget-container">
                                <div class="jet-listing-grid jet-listing">
                                    <div class="jet-listing-grid__slider"
                                        data-slider_options="{&quot;slidesToShow&quot;:{&quot;desktop&quot;:3,&quot;tablet&quot;:3,&quot;mobile&quot;:2},&quot;autoplaySpeed&quot;:5000,&quot;autoplay&quot;:true,&quot;infinite&quot;:true,&quot;centerMode&quot;:false,&quot;speed&quot;:500,&quot;arrows&quot;:false,&quot;dots&quot;:true,&quot;slidesToScroll&quot;:1,&quot;prevArrow&quot;:&quot;<div class=\&quot;jet-listing-grid__slider-icon prev-arrow \&quot; role=\&quot;button\&quot; aria-label=\&quot;Previous\&quot;><svg viewBox=\&quot;0 0 90 179\&quot; xmlns=\&quot;http:\/\/www.w3.org\/2000\/svg\&quot;><path transform=\&quot;scale(0.1,-0.1) translate(0,-1536)\&quot; d=\&quot;M627 992q0 -13 -10 -23l-393 -393l393 -393q10 -10 10 -23t-10 -23l-50 -50q-10 -10 -23 -10t-23 10l-466 466q-10 10 -10 23t10 23l466 466q10 10 23 10t23 -10l50 -50q10 -10 10 -23z\&quot; \/><\/svg><\/div>&quot;,&quot;nextArrow&quot;:&quot;<div class=\&quot;jet-listing-grid__slider-icon next-arrow \&quot; role=\&quot;button\&quot; aria-label=\&quot;Next\&quot;><svg viewBox=\&quot;0 0 90 179\&quot; xmlns=\&quot;http:\/\/www.w3.org\/2000\/svg\&quot;><path transform=\&quot;scale(0.1,-0.1) translate(0,-1536)\&quot; d=\&quot;M627 992q0 -13 -10 -23l-393 -393l393 -393q10 -10 10 -23t-10 -23l-50 -50q-10 -10 -23 -10t-23 10l-466 466q-10 10 -10 23t10 23l466 466q10 10 23 10t23 -10l50 -50q10 -10 10 -23z\&quot; \/><\/svg><\/div>&quot;,&quot;rtl&quot;:false,&quot;itemsCount&quot;:4,&quot;fade&quot;:false}"
                                        dir="ltr">
                                        <div class="jet-listing-grid__items grid-col-desk-3 grid-col-tablet-3 grid-col-mobile-2 jet-listing-grid--14 slick-initialized slick-slider slick-dotted"
                                            data-nav="{&quot;enabled&quot;:false,&quot;type&quot;:null,&quot;more_el&quot;:null,&quot;query&quot;:[],&quot;widget_settings&quot;:{&quot;lisitng_id&quot;:14,&quot;posts_num&quot;:6,&quot;columns&quot;:3,&quot;columns_tablet&quot;:3,&quot;columns_mobile&quot;:2,&quot;is_archive_template&quot;:&quot;&quot;,&quot;post_status&quot;:[&quot;publish&quot;],&quot;use_random_posts_num&quot;:&quot;&quot;,&quot;max_posts_num&quot;:9,&quot;not_found_message&quot;:&quot;Tidak ada artikel&quot;,&quot;is_masonry&quot;:false,&quot;equal_columns_height&quot;:&quot;&quot;,&quot;use_load_more&quot;:&quot;&quot;,&quot;load_more_id&quot;:&quot;&quot;,&quot;load_more_type&quot;:&quot;click&quot;,&quot;use_custom_post_types&quot;:&quot;&quot;,&quot;custom_post_types&quot;:[],&quot;hide_widget_if&quot;:&quot;&quot;,&quot;carousel_enabled&quot;:&quot;yes&quot;,&quot;slides_to_scroll&quot;:&quot;1&quot;,&quot;arrows&quot;:&quot;true&quot;,&quot;arrow_icon&quot;:&quot;fa fa-angle-left&quot;,&quot;dots&quot;:&quot;true&quot;,&quot;autoplay&quot;:&quot;true&quot;,&quot;autoplay_speed&quot;:5000,&quot;infinite&quot;:&quot;true&quot;,&quot;center_mode&quot;:&quot;&quot;,&quot;effect&quot;:&quot;slide&quot;,&quot;speed&quot;:500,&quot;inject_alternative_items&quot;:&quot;&quot;,&quot;injection_items&quot;:[],&quot;scroll_slider_enabled&quot;:&quot;&quot;,&quot;scroll_slider_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;custom_query&quot;:false,&quot;custom_query_id&quot;:&quot;&quot;,&quot;_element_id&quot;:&quot;&quot;}}"
                                            data-page="1" data-pages="1" data-listing-source="posts">
                                            <div class="slick-list draggable">
                                                <div class="slick-track"
                                                    style="opacity: 1; width: 1540px; transform: translate3d(-616px, 0px, 0px);">
                                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-1270 slick-slide slick-cloned"
                                                        data-post-id="1270" style="width: 154px;" tabindex="-1"
                                                        role="tabpanel" id=""
                                                        aria-describedby="slick-slide-control02" data-slick-index="-2"
                                                        aria-hidden="true">
                                                        <style type="text/css">
                                                            .jet-listing-dynamic-post-1270 .elementor-element.elementor-element-a0098aa .jet-listing-dynamic-terms__link {
                                                                background-color: #03626f;
                                                            }

                                                            .jet-listing-dynamic-post-1270 .elementor-element.elementor-element-a0098aa .jet-listing-dynamic-terms__link:hover {
                                                                background-color: #ffa800;
                                                            }
                                                        </style>
                                                        <div data-elementor-type="jet-listing-items"
                                                            data-elementor-id="14" class="elementor elementor-14">
                                                            <section
                                                                class="elementor-section elementor-top-section elementor-element elementor-element-ba02864 elementor-section-boxed elementor-section-height-default elementor-section-height-default jet-parallax-section"
                                                                data-id="ba02864" data-element_type="section"
                                                                data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;fb4688d&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                                                                <div
                                                                    class="elementor-container elementor-column-gap-default">
                                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b7fb4ee"
                                                                        data-id="b7fb4ee" data-element_type="column">
                                                                        <div
                                                                            class="elementor-widget-wrap elementor-element-populated">
                                                                            <div class="elementor-element elementor-element-b1c7cf7 elementor-widget elementor-widget-image"
                                                                                data-id="b1c7cf7"
                                                                                data-element_type="widget"
                                                                                data-widget_type="image.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <a href="../test-artikel/index.html"
                                                                                        tabindex="-1">
                                                                                        <img width="640"
                                                                                            height="426"
                                                                                            src="../wp-content/uploads/2022/04/art2.jpg"
                                                                                            class="attachment-full size-full wp-image-1224"
                                                                                            alt=""
                                                                                            srcset="https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/art2.jpg 640w, https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/art2-300x200.jpg 300w"
                                                                                            sizes="(max-width: 640px) 100vw, 640px">
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-a0098aa elementor-widget__width-auto elementor-widget elementor-widget-jet-listing-dynamic-terms"
                                                                                data-id="a0098aa"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-terms.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-terms">
                                                                                        <a href="../Topik/berita/index.html"
                                                                                            class="jet-listing-dynamic-terms__link"
                                                                                            tabindex="-1">Berita</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-2b008ec elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                                data-id="2b008ec"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-field.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-field display-inline">
                                                                                        <div
                                                                                            class="jet-listing-dynamic-field__inline-wrap">
                                                                                            <div
                                                                                                class="jet-listing-dynamic-field__content">
                                                                                                Test Artikel</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-727cf7f elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                                data-id="727cf7f"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-field.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-field display-inline">
                                                                                        <div
                                                                                            class="jet-listing-dynamic-field__inline-wrap">
                                                                                            <div
                                                                                                class="jet-listing-dynamic-field__content">
                                                                                                Lorem ipsum dolor sit
                                                                                                amet, consectetur
                                                                                                adipiscing elit. Nam
                                                                                                s...</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </section>
                                                        </div>
                                                    </div>
                                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-1268 slick-slide slick-cloned"
                                                        data-post-id="1268" style="width: 154px;" tabindex="-1"
                                                        role="tabpanel" id=""
                                                        aria-describedby="slick-slide-control03" data-slick-index="-1"
                                                        aria-hidden="true">
                                                        <style type="text/css">
                                                            .jet-listing-dynamic-post-1268 .elementor-element.elementor-element-a0098aa .jet-listing-dynamic-terms__link {
                                                                background-color: #03626f;
                                                            }

                                                            .jet-listing-dynamic-post-1268 .elementor-element.elementor-element-a0098aa .jet-listing-dynamic-terms__link:hover {
                                                                background-color: #ffa800;
                                                            }
                                                        </style>
                                                        <div data-elementor-type="jet-listing-items"
                                                            data-elementor-id="14" class="elementor elementor-14">
                                                            <section
                                                                class="elementor-section elementor-top-section elementor-element elementor-element-ba02864 elementor-section-boxed elementor-section-height-default elementor-section-height-default jet-parallax-section"
                                                                data-id="ba02864" data-element_type="section"
                                                                data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;fb4688d&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                                                                <div
                                                                    class="elementor-container elementor-column-gap-default">
                                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b7fb4ee"
                                                                        data-id="b7fb4ee" data-element_type="column">
                                                                        <div
                                                                            class="elementor-widget-wrap elementor-element-populated">
                                                                            <div class="elementor-element elementor-element-b1c7cf7 elementor-widget elementor-widget-image"
                                                                                data-id="b1c7cf7"
                                                                                data-element_type="widget"
                                                                                data-widget_type="image.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <a href="../selamat-datang-di-flymotion/index.html"
                                                                                        tabindex="-1">
                                                                                        <img loading="lazy"
                                                                                            width="640"
                                                                                            height="426"
                                                                                            src="../wp-content/uploads/2022/04/art1.jpg"
                                                                                            class="attachment-full size-full wp-image-1225"
                                                                                            alt=""
                                                                                            srcset="https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/art1.jpg 640w, https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/art1-300x200.jpg 300w"
                                                                                            sizes="(max-width: 640px) 100vw, 640px">
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-a0098aa elementor-widget__width-auto elementor-widget elementor-widget-jet-listing-dynamic-terms"
                                                                                data-id="a0098aa"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-terms.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-terms">
                                                                                        <a href="../Topik/berita/index.html"
                                                                                            class="jet-listing-dynamic-terms__link"
                                                                                            tabindex="-1">Berita</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-2b008ec elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                                data-id="2b008ec"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-field.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-field display-inline">
                                                                                        <div
                                                                                            class="jet-listing-dynamic-field__inline-wrap">
                                                                                            <div
                                                                                                class="jet-listing-dynamic-field__content">
                                                                                                Selamat Datang di
                                                                                                Flymotion</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-727cf7f elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                                data-id="727cf7f"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-field.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-field display-inline">
                                                                                        <div
                                                                                            class="jet-listing-dynamic-field__inline-wrap">
                                                                                            <div
                                                                                                class="jet-listing-dynamic-field__content">
                                                                                                Lorem ipsum dolor sit
                                                                                                amet, consectetur
                                                                                                adipiscing elit. Nam
                                                                                                s...</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </section>
                                                        </div>
                                                    </div>
                                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-1620 slick-slide"
                                                        data-post-id="1620" style="width: 154px;" tabindex="-1"
                                                        role="tabpanel" id="slick-slide00"
                                                        aria-describedby="slick-slide-control00" data-slick-index="0"
                                                        aria-hidden="true">
                                                        <style type="text/css">
                                                            .jet-listing-dynamic-post-1620 .elementor-element.elementor-element-a0098aa .jet-listing-dynamic-terms__link {
                                                                background-color: #03626f;
                                                            }

                                                            .jet-listing-dynamic-post-1620 .elementor-element.elementor-element-a0098aa .jet-listing-dynamic-terms__link:hover {
                                                                background-color: #ffa800;
                                                            }
                                                        </style>
                                                        <div data-elementor-type="jet-listing-items"
                                                            data-elementor-id="14" class="elementor elementor-14">
                                                            <section
                                                                class="elementor-section elementor-top-section elementor-element elementor-element-ba02864 elementor-section-boxed elementor-section-height-default elementor-section-height-default jet-parallax-section"
                                                                data-id="ba02864" data-element_type="section"
                                                                data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;fb4688d&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                                                                <div
                                                                    class="elementor-container elementor-column-gap-default">
                                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b7fb4ee"
                                                                        data-id="b7fb4ee" data-element_type="column">
                                                                        <div
                                                                            class="elementor-widget-wrap elementor-element-populated">
                                                                            <div class="elementor-element elementor-element-b1c7cf7 elementor-widget elementor-widget-image"
                                                                                data-id="b1c7cf7"
                                                                                data-element_type="widget"
                                                                                data-widget_type="image.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <a href="../coba/index.html"
                                                                                        tabindex="-1">
                                                                                        <img src="{{ asset('wp-content/uploads/2022/04/featured.jpg') }}"
                                                                                            title=""
                                                                                            alt=""
                                                                                            loading="lazy"> </a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-a0098aa elementor-widget__width-auto elementor-widget elementor-widget-jet-listing-dynamic-terms"
                                                                                data-id="a0098aa"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-terms.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-terms">
                                                                                        <a href="../Topik/berita/index.html"
                                                                                            class="jet-listing-dynamic-terms__link"
                                                                                            tabindex="-1">Berita</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-2b008ec elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                                data-id="2b008ec"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-field.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-field display-inline">
                                                                                        <div
                                                                                            class="jet-listing-dynamic-field__inline-wrap">
                                                                                            <div
                                                                                                class="jet-listing-dynamic-field__content">
                                                                                                coba</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-727cf7f elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                                data-id="727cf7f"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-field.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-field display-inline">
                                                                                        <div
                                                                                            class="jet-listing-dynamic-field__inline-wrap">
                                                                                            <div
                                                                                                class="jet-listing-dynamic-field__content">
                                                                                                coba</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </section>
                                                        </div>
                                                    </div>
                                                    <div class="jet-listing-grid__item jet-listing-dynamic-post-1272 slick-slide"
                                                        data-post-id="1272" style="width: 154px;" tabindex="-1"
                                                        role="tabpanel" id="slick-slide01"
                                                        aria-describedby="slick-slide-control01" data-slick-index="1"
                                                        aria-hidden="true">
                                                        <style type="text/css">
                                                            .jet-listing-dynamic-post-1272 .elementor-element.elementor-element-a0098aa .jet-listing-dynamic-terms__link {
                                                                background-color: #03626f;
                                                            }

                                                            .jet-listing-dynamic-post-1272 .elementor-element.elementor-element-a0098aa .jet-listing-dynamic-terms__link:hover {
                                                                background-color: #ffa800;
                                                            }
                                                        </style>
                                                        <div data-elementor-type="jet-listing-items"
                                                            data-elementor-id="14" class="elementor elementor-14">
                                                            <section
                                                                class="elementor-section elementor-top-section elementor-element elementor-element-ba02864 elementor-section-boxed elementor-section-height-default elementor-section-height-default jet-parallax-section"
                                                                data-id="ba02864" data-element_type="section"
                                                                data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;fb4688d&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                                                                <div
                                                                    class="elementor-container elementor-column-gap-default">
                                                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b7fb4ee"
                                                                        data-id="b7fb4ee" data-element_type="column">
                                                                        <div
                                                                            class="elementor-widget-wrap elementor-element-populated">
                                                                            <div class="elementor-element elementor-element-b1c7cf7 elementor-widget elementor-widget-image"
                                                                                data-id="b1c7cf7"
                                                                                data-element_type="widget"
                                                                                data-widget_type="image.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <a href="index.html"
                                                                                        tabindex="-1">
                                                                                        <img fetchpriority="high"
                                                                                            width="640"
                                                                                            height="426"
                                                                                            src="../wp-content/uploads/2022/04/uji.jpg"
                                                                                            class="attachment-full size-full wp-image-1206"
                                                                                            alt=""
                                                                                            srcset="https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/uji.jpg 640w, https://sekolah.flymotion.my.id/wp-content/uploads/2022/04/uji-300x200.jpg 300w"
                                                                                            sizes="(max-width: 640px) 100vw, 640px">
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-a0098aa elementor-widget__width-auto elementor-widget elementor-widget-jet-listing-dynamic-terms"
                                                                                data-id="a0098aa"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-terms.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-terms">
                                                                                        <a href="../Topik/berita/index.html"
                                                                                            class="jet-listing-dynamic-terms__link"
                                                                                            tabindex="-1">Berita</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-2b008ec elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                                data-id="2b008ec"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-field.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-field display-inline">
                                                                                        <div
                                                                                            class="jet-listing-dynamic-field__inline-wrap">
                                                                                            <div
                                                                                                class="jet-listing-dynamic-field__content">
                                                                                                Hello Dunia Tipu-tipu
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="elementor-element elementor-element-727cf7f elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                                data-id="727cf7f"
                                                                                data-element_type="widget"
                                                                                data-widget_type="jet-listing-dynamic-field.default">
                                                                                <div
                                                                                    class="elementor-widget-container">
                                                                                    <div
                                                                                        class="jet-listing jet-listing-dynamic-field display-inline">
                                                                                        <div
                                                                                            class="jet-listing-dynamic-field__inline-wrap">
                                                                                            <div
                                                                                                class="jet-listing-dynamic-field__content">
                                                                                                Lorem ipsum dolor sit
                                                                                                amet, consectetur
                                                                                                adipiscing elit. Nam
                                                                                                s...</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </section>
                                                        </div>
                                                    </div>
                                                    @foreach ($berita as $item)
                                                        <div class="jet-listing-grid__item jet-listing-dynamic-post-1270 slick-slide slick-current slick-active"
                                                            data-post-id="1270" style="width: 154px;" tabindex="0"
                                                            role="tabpanel" id="slick-slide02"
                                                            aria-describedby="slick-slide-control02"
                                                            data-slick-index="2" aria-hidden="false">
                                                            <style type="text/css">
                                                                .jet-listing-dynamic-post-1270 .elementor-element.elementor-element-a0098aa .jet-listing-dynamic-terms__link {
                                                                    background-color: #03626f;
                                                                }

                                                                .jet-listing-dynamic-post-1270 .elementor-element.elementor-element-a0098aa .jet-listing-dynamic-terms__link:hover {
                                                                    background-color: #ffa800;
                                                                }
                                                            </style>
                                                            <div data-elementor-type="jet-listing-items"
                                                                data-elementor-id="14" class="elementor elementor-14">
                                                                <section
                                                                    class="elementor-section elementor-top-section elementor-element elementor-element-ba02864 elementor-section-boxed elementor-section-height-default elementor-section-height-default jet-parallax-section"
                                                                    data-id="ba02864" data-element_type="section"
                                                                    data-settings="{&quot;jet_parallax_layout_list&quot;:[{&quot;jet_parallax_layout_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;_id&quot;:&quot;fb4688d&quot;,&quot;jet_parallax_layout_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;jet_parallax_layout_speed&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;jet_parallax_layout_type&quot;:&quot;scroll&quot;,&quot;jet_parallax_layout_direction&quot;:null,&quot;jet_parallax_layout_fx_direction&quot;:null,&quot;jet_parallax_layout_z_index&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x&quot;:50,&quot;jet_parallax_layout_bg_x_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_x_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y&quot;:50,&quot;jet_parallax_layout_bg_y_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_y_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size&quot;:&quot;auto&quot;,&quot;jet_parallax_layout_bg_size_tablet&quot;:&quot;&quot;,&quot;jet_parallax_layout_bg_size_mobile&quot;:&quot;&quot;,&quot;jet_parallax_layout_animation_prop&quot;:&quot;transform&quot;,&quot;jet_parallax_layout_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;]}]}">
                                                                    <div
                                                                        class="elementor-container elementor-column-gap-default">
                                                                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b7fb4ee"
                                                                            data-id="b7fb4ee"
                                                                            data-element_type="column">
                                                                            <div
                                                                                class="elementor-widget-wrap elementor-element-populated">
                                                                                <div class="elementor-element elementor-element-b1c7cf7 elementor-widget elementor-widget-image"
                                                                                    data-id="b1c7cf7"
                                                                                    data-element_type="widget"
                                                                                    data-widget_type="image.default">
                                                                                    <div
                                                                                        class="elementor-widget-container">
                                                                                        <a href="{{ route('beritaDetailComponent', $item->slug) }}"
                                                                                            tabindex="0">
                                                                                            <img width="640"
                                                                                                height="426"
                                                                                                src="{{ asset($item->thumbnail) }}"
                                                                                                class="attachment-full size-full wp-image-1224"
                                                                                                alt="{{ $item->judul }}"
                                                                                                sizes="(max-width: 640px) 100vw, 640px">
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="elementor-element elementor-element-a0098aa elementor-widget__width-auto elementor-widget elementor-widget-jet-listing-dynamic-terms"
                                                                                    data-id="a0098aa"
                                                                                    data-element_type="widget"
                                                                                    data-widget_type="jet-listing-dynamic-terms.default">
                                                                                    <div
                                                                                        class="elementor-widget-container">
                                                                                        <div
                                                                                            class="jet-listing jet-listing-dynamic-terms">
                                                                                            <a href=".#"
                                                                                                class="jet-listing-dynamic-terms__link"
                                                                                                tabindex="0">{{ $item->kategori }}</a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="elementor-element elementor-element-2b008ec elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                                    data-id="2b008ec"
                                                                                    data-element_type="widget"
                                                                                    data-widget_type="jet-listing-dynamic-field.default">
                                                                                    <div
                                                                                        class="elementor-widget-container">
                                                                                        <div
                                                                                            class="jet-listing jet-listing-dynamic-field display-inline">
                                                                                            <div
                                                                                                class="jet-listing-dynamic-field__inline-wrap">
                                                                                                <div
                                                                                                    class="jet-listing-dynamic-field__content">
                                                                                                    {{ $item->judul }}
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="elementor-element elementor-element-727cf7f elementor-widget elementor-widget-jet-listing-dynamic-field"
                                                                                    data-id="727cf7f"
                                                                                    data-element_type="widget"
                                                                                    data-widget_type="jet-listing-dynamic-field.default">
                                                                                    <div
                                                                                        class="elementor-widget-container">
                                                                                        <div
                                                                                            class="jet-listing jet-listing-dynamic-field display-inline">
                                                                                            <div
                                                                                                class="jet-listing-dynamic-field__inline-wrap">
                                                                                                <div
                                                                                                    class="jet-listing-dynamic-field__content">
                                                                                                    {!! \Illuminate\Support\Str::limit(strip_tags($item->content), 100, '...') !!}
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </section>
                                                            </div>
                                                        </div>
                                                    @endforeach ($berita as $item)







                                                </div>
                                            </div>
                                            <ul class="jet-slick-dots" style="" role="tablist">
                                                <li class="" role="presentation"><span>1</span></li>
                                                <li class="" role="presentation"><span>2</span></li>
                                                <li role="presentation" class="slick-active"><span>3</span></li>
                                                <li role="presentation" class=""><span>4</span></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-3a76c061 elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                            data-id="3a76c061" data-element_type="widget" data-widget_type="divider.default">
                            <div class="elementor-widget-container">
                                <div class="elementor-divider">
                                    <span class="elementor-divider-separator">
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
